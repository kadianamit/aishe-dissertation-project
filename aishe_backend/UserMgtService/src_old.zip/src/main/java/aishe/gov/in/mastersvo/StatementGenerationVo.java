package aishe.gov.in.mastersvo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigInteger;

@Setter
@Getter
@AllArgsConstructor
@Builder
@RequiredArgsConstructor
public class StatementGenerationVo {
    @NotNull
    @Min(value = 0, message = "The value must be positive")
    private Integer formUploadId;
    @NotNull
    @Min(value = 0, message = "The value must be positive")
    private Integer noOfProgramme;

    private Boolean constitutedFromColleges;
    @NotNull
    @Min(value = 0, message = "The value must be positive")
    private BigInteger amount;
    @NotNull
    @Min(value = 0, message = "The value must be positive")
    private Integer normTypeId;
}
