package aishe.gov.in.utility;

public class ResponseIdMap {

    private int id;
    private int countByCategoryId;
    private Boolean flag = true;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCountByCategoryId() {
        return countByCategoryId;
    }

    public void setCountByCategoryId(int countByCategoryId) {
        this.countByCategoryId = countByCategoryId;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }
}
