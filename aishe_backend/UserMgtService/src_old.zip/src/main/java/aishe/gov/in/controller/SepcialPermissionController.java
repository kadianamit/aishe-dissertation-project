package aishe.gov.in.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import aishe.gov.in.enums.ActionConstant;
import aishe.gov.in.enums.OrderBy;
import aishe.gov.in.enums.SurveyYearConstant;
import aishe.gov.in.enums.SurveyYearDropDown;
import aishe.gov.in.mastersvo.UnlockVO;
import aishe.gov.in.service.JasperGeneratorService;
import aishe.gov.in.service.LockService;
import aishe.gov.in.service.SpecialPermissionService;
import aishe.gov.in.utility.Constant;
import aishe.gov.in.utility.ReturnResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

@RestController
public class SepcialPermissionController {

    private static final Logger logger = LoggerFactory.getLogger(SepcialPermissionController.class);

    @Autowired
    private SpecialPermissionService specialPermissionService;
    
    @Autowired
    private LockService lockService;

    @Autowired
    private JasperGeneratorService jasperGeneratorService;
    @PostMapping(value ="/assignspecialpermission")
	public ResponseEntity<ReturnResponse> assignSpecialPermissionToInstitute(@RequestParam(required=true) String instituteType,@RequestParam(required=true) String aisheCode,@RequestParam(required=false) String username,
			@RequestParam(required=true) SurveyYearDropDown surveyYear, @RequestParam (required = true, defaultValue = "false") Boolean specialPermission,@RequestParam(required=false) String userKey
			,@RequestParam(required = false) String remarks,HttpServletRequest request){
		logger.info("assignspecialpermission api invoked");
		//if(userKey.equals("MOEUSERONLY") && (username.equals("aishe.nic") || username.equals("riteshpatel"))) {
		if (/*
			 * (userKey.equals("NIC@Aishe123") && (username.equals("aishe.nic") ||
			 * username.equals("riteshpatel"))) &&
			 */
				//(
						surveyYear.getStatusType().equals(SurveyYearDropDown.SURVEY_YEAR_2022.getStatusType()))
				//) 
{
		boolean isUniversityHostelDeleted = specialPermissionService.assignSpecialPermissionToInstitute(instituteType,aisheCode,username,surveyYear.getStatusType(),specialPermission.booleanValue(),remarks,request);
		if (isUniversityHostelDeleted) {
			return new ResponseEntity<>(
					new ReturnResponse(HttpStatus.OK.value(), "Special Permission To Institute has been  Successfully Done!!"),
					HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(new ReturnResponse(HttpStatus.BAD_REQUEST.value(),
					"Request Cannot Be Processed. Please Try Again."), HttpStatus.BAD_REQUEST);
		}
		}else {
			return new ResponseEntity<>(new ReturnResponse(HttpStatus.BAD_REQUEST.value(),
					"Request Cannot Be Processed. Please Try Again."), HttpStatus.BAD_REQUEST);
		}
	}
    @GetMapping("webdcf-log-reports")
    public void webdcfLogReportsExcel(@RequestParam(required=false) SurveyYearConstant surveyYearConstant,@RequestParam ActionConstant action,@RequestParam(required=false) OrderBy orderBy,
    		@RequestParam(required=false) Integer surveyYear,@RequestParam(required=false) String stateCode,@RequestParam(required=false,defaultValue = "ALL") String instituteType,
    		HttpServletResponse response) throws JRException, IOException, SQLException {
        logger.info("university teacher  jasper report generating pdf file and fill parameter into the template");
        InputStream stream;
        URL path1;
        stream = this.getClass().getResourceAsStream(Constant.SEPCIAL_PERMISSION + "Special_Permission.jrxml");
        path1 = this.getClass().getResource(Constant.SEPCIAL_PERMISSION);
        if(action.getStatusType()==37) {
        	 stream = this.getClass().getResourceAsStream(Constant.WEBDCF_UNLOCK + "Unlock_Institution_List.jrxml");
        	 path1 = this.getClass().getResource(Constant.WEBDCF_UNLOCK);
        }
        final JasperReport report = JasperCompileManager.compileReport(stream);
        final Map<String, Object> parameters = new HashMap<>();
		if (surveyYear != null && action.getStatusType() == 37) {
			parameters.put("survey_year", surveyYear);
		} else if (surveyYear != null) {
			parameters.put("survey_year", surveyYear.toString());
		} else if (action.getStatusType() == 37) {
			parameters.put("survey_year", surveyYearConstant.getStatusType().toString());
		}
        if(stateCode!=null) {
        parameters.put("state_code", stateCode);
        }else {
        	 parameters.put("state_code", "ALL");
        }
		if (instituteType != null) {
			parameters.put("institution_type", instituteType);
		}
        parameters.put("real_path", path1.toString());
        parameters.put("action_id", action.getStatusType().toString());
        parameters.put("action_name", action.name());
        Connection connection = jasperGeneratorService.findConnection();
        final JasperPrint print = JasperFillManager.fillReport(report, parameters, connection);
        response.setContentType(Constant.EXCEL_XLS_CONTENT_TYPE);
		//fileName = reportFileName + " " + Util.getTimeStamp() + ".xlsx";
        response.setHeader(Constant.CONTENT_DISPOSITION, String.format("attachment;filename=WEB_DCF_"+action.name()+".xlsx"));
        OutputStream out = response.getOutputStream();
        
        JRXlsxExporter jrXLSXExporter = new JRXlsxExporter();

		jrXLSXExporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
		jrXLSXExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, out);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, true);

		jrXLSXExporter.exportReport();
        
        
       // JasperExportManager.exportReportToPdfStream(print, out);
        connection.close();
        out.close();
        logger.info("successfully generated university Teacher dcf pdf  file and successfully filled parameter into the template");
    }
    
    @PostMapping(value = "/api/webdcf-unlock")
	public ResponseEntity<ReturnResponse> unlockWebdcf(@RequestBody UnlockVO unlockVO,HttpServletRequest request) {
    	boolean isUnlock=false;
		if (/*
			 * unlockVO.getUserKey().equals("NIC@Aishe123") &&
			 * (unlockVO.getUserName().equals("aishe.nic") ||
			 * unlockVO.getUserName().equals("riteshpatel")) &&
			 */ unlockVO.getSurveyYear().equals(SurveyYearDropDown.SURVEY_YEAR_2022.getStatusType())) {
			isUnlock = lockService.unlockWebdcf(unlockVO,request);
    	}
			if (isUnlock) {
				return new ResponseEntity<>(
						new ReturnResponse(HttpStatus.OK.value(), "DCF has been Successfully UnLocked!!"),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ReturnResponse(HttpStatus.BAD_REQUEST.value(),
						"Please Try Again With Correct Input Aishe_Code(Like 12345), Inst_type(Like C,S,U),Survey_Year(Only 2022), User_name or User_Key."), HttpStatus.BAD_REQUEST);
			
	       }
			}
    
   // @GetMapping("webdcf-unlock-log-excel")
    public void webdcfUnlockReportExcel(@RequestParam SurveyYearConstant surveyYear, HttpServletResponse response) throws JRException, IOException, SQLException {
        logger.info("university teacher  jasper report generating pdf file and fill parameter into the template");
        final InputStream stream;
        URL path1;
        if(surveyYear.getStatusType()>=2020) {
        	 stream = this.getClass().getResourceAsStream(Constant.WEBDCF_UNLOCK + "Unlock_Institution_List.jrxml");
        	 path1 = this.getClass().getResource(Constant.WEBDCF_UNLOCK);
        	 
        }else {
        	 stream = this.getClass().getResourceAsStream(Constant.REGIONAL_CENTER_ONE + ".jrxml");
        	 path1 = this.getClass().getResource(Constant.REGIONAL_CENTER_ONE);
        }
        final JasperReport report = JasperCompileManager.compileReport(stream);
        final Map<String, Object> parameters = new HashMap<>();
        parameters.put("survey_year", surveyYear.getStatusType());
        parameters.put("real_path", path1.toString());
        Connection connection = jasperGeneratorService.findConnection();
        final JasperPrint print = JasperFillManager.fillReport(report, parameters, connection);
        response.setContentType(Constant.EXCEL_XLS_CONTENT_TYPE);
		//fileName = reportFileName + " " + Util.getTimeStamp() + ".xlsx";
        response.setHeader(Constant.CONTENT_DISPOSITION, String.format("attachment;filename=WEBDCF_UNLOCK.xlsx"));
        OutputStream out = response.getOutputStream();
        
        JRXlsxExporter jrXLSXExporter = new JRXlsxExporter();

		jrXLSXExporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
		jrXLSXExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, out);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
		jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, true);

		jrXLSXExporter.exportReport();
        
        
       // JasperExportManager.exportReportToPdfStream(print, out);
        connection.close();
        out.close();
        logger.info("successfully generated university Teacher dcf pdf  file and successfully filled parameter into the template");
    }
}