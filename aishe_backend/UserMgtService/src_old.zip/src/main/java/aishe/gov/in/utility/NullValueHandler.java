package aishe.gov.in.utility;

import aishe.gov.in.enums.ExportType;
import lombok.extern.log4j.Log4j2;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

@Component
@Log4j2
public class NullValueHandler {
    public String nullValueHandler(String value) {
        if (null != value)
            return value.equalsIgnoreCase("null") ? null : value;
        return null;
    }

    public String allAssignForNull(String value) {
        if (null != value && !value.isEmpty())
            return value.equalsIgnoreCase("null") ? "ALL" : value;
        return "ALL";
    }

    public Integer nullValueHandleInteger(String value) {
        if (null != value)
            return value.equalsIgnoreCase("null") ? null : Integer.valueOf(value);
        return null;
    }

    public Boolean nullValueHandlerBoolean(String value) {
        if (null != value)
            return value.equalsIgnoreCase("null") ? null : Boolean.valueOf(value);
        return null;
    }


    public byte[]
    exportReport(JRDataSource customDataSource, String reportFormatType, JasperReport jasperReport,
                 Map<String, Object> parameters) throws JRException {
        try {

            if (ExportType.PDF.type.equals(reportFormatType)) {
                return JasperRunManager.runReportToPdf(jasperReport, parameters, customDataSource);
            } else if (ExportType.EXCEL.type.equals(reportFormatType)) {
                return exportReportToExcel(customDataSource, jasperReport, parameters);
            } else if (ExportType.CSV.type.equals(reportFormatType)) {

                return exportReportToCSV(customDataSource, jasperReport, parameters);
            }
        } catch (Exception e) {
            log.error("Exception in class: GenerateReportAction and method: exportReport()- ", e);
            log.error("Exception while exporting report.");
        }
        return null;
    }


    private byte[] exportReportToExcel(JRDataSource customDataSource, JasperReport jasperReport, Map<String, Object> parameters) throws JRException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        parameters.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, customDataSource);
        JRXlsxExporter exporter = new JRXlsxExporter();
        ByteArrayOutputStream xlsReport = new ByteArrayOutputStream();
        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(xlsReport));

        SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
        configuration.setOnePagePerSheet(Boolean.FALSE);
        configuration.setDetectCellType(Boolean.TRUE);
        configuration.setWhitePageBackground(Boolean.TRUE);
        configuration.setRemoveEmptySpaceBetweenRows(Boolean.TRUE);
        configuration.setRemoveEmptySpaceBetweenColumns(Boolean.TRUE);
        configuration.setImageBorderFixEnabled(Boolean.TRUE);
        configuration.setCollapseRowSpan(Boolean.TRUE);

        /*jrXLSXExporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
        jrXLSXExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
        jrXLSXExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, true);
        jrXLSXExporter.exportReport();*/
        return byteArrayOutputStream.toByteArray();
    }

    private byte[] exportReportToCSV(JRDataSource customDataSource, JasperReport jasperReport, Map<String, Object> parameters) throws JRException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        parameters.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);

        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, customDataSource);
        JRCsvExporter exporter = new JRCsvExporter();
        ByteArrayOutputStream xlsReport = new ByteArrayOutputStream();
        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleWriterExporterOutput(xlsReport));
        SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
        configuration.setOnePagePerSheet(Boolean.FALSE);
        configuration.setDetectCellType(Boolean.TRUE);
        configuration.setWhitePageBackground(Boolean.TRUE);
        configuration.setRemoveEmptySpaceBetweenRows(Boolean.TRUE);
        configuration.setRemoveEmptySpaceBetweenColumns(Boolean.TRUE);
        configuration.setImageBorderFixEnabled(Boolean.TRUE);
        configuration.setCollapseRowSpan(Boolean.TRUE);
        /*exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);
        exporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
        exporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IS_IGNORE_CELL_BORDER, Boolean.FALSE);
        exporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IGNORE_PAGE_MARGINS, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
        exporter.setParameter(JRXlsExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
        exporter.exportReport();*/
        return byteArrayOutputStream.toByteArray();
    }

    public byte[] fileExportByType(ExportType exportType, JasperPrint print) throws JRException, IOException {
        switch (exportType.getType()) {
            case "PDF": {
                 /*response.setContentType(ReportsConstant.APPLICATION_X_DOWNLOAD);
                 JasperExportManager.exportReportToPdfStream(print, out);*/
                byte[] byteArray = JasperExportManager.exportReportToPdf(print);
                return byteArray;
            }
            case "EXCEL": {
                // response.setContentType(ReportsConstant.EXCEL_CONTENT_TYPE);
                JRXlsxExporter exporter = new JRXlsxExporter();
                ByteArrayOutputStream xlsReport = new ByteArrayOutputStream();
                exporter.setExporterInput(new SimpleExporterInput(print));
                exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(xlsReport));
                SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
                configuration.setOnePagePerSheet(Boolean.FALSE);
                configuration.setDetectCellType(Boolean.TRUE);
                configuration.setWhitePageBackground(Boolean.TRUE);
                configuration.setRemoveEmptySpaceBetweenRows(Boolean.TRUE);
                configuration.setRemoveEmptySpaceBetweenColumns(Boolean.TRUE);
                configuration.setImageBorderFixEnabled(Boolean.TRUE);
                configuration.setCollapseRowSpan(Boolean.TRUE);

                //  exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
                //  exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, xlsReport);

                // exporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
                // exporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
                // exporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);
                // exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
                // exporter.setParameter(JRXlsExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
                // exporter.setParameter(JRXlsExporterParameter.IS_COLLAPSE_ROW_SPAN, Boolean.TRUE);
                // exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, true);
                exporter.exportReport();
                byte[] byteArray = xlsReport.toByteArray();
                xlsReport.close();
                return byteArray;

            }


            default: {
                break;
            }
        }
        return new byte[0];
    }

    public String process(Object value) {
        if (null != value) {
            if (value instanceof Boolean) {
                return (Boolean) value == true ? "YES" : "NO";
            }
            return value.toString();
        }
        return "";
    }
}
