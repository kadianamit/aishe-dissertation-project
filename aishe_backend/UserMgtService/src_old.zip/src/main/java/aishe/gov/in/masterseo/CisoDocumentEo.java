package aishe.gov.in.masterseo;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@RequiredArgsConstructor
@Setter
@Getter
@Entity
@Builder
@Table(name = "ciso.document")
public class CisoDocumentEo {
    @Id
    @GenericGenerator(name="documentciso" , strategy="increment")
	@GeneratedValue(generator="documentciso")
    private Integer id;
   
    @Column(name = "title")
    private String title;
    
    @Column(name = "document_type")
    private String documentType;
    
    @Column(name = "document_file")
    private byte[] documentFile;
    
    @Column(name = "uploaded_by")
    private String uploadedBy;
    
    @Column(name = "date_time")
    private LocalDateTime dateTime;
    
    @Column(name = "file_name")
    private String fileName;

}