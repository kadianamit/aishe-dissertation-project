package aishe.gov.in.utility;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Embeddable
public class RemunerationKey implements Serializable {
    @Min(1)
    @Max(9999)
    @Column(name = "survey_year")
    private Integer surveyYear;
    @NotNull
    @NotBlank
    @Column(name = "form_id")
    private String formId;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof SurveyStatusKey))
            return false;
        RemunerationKey that = (RemunerationKey) o;
        return Objects.equals(getFormId(), that.getFormId()) && Objects.equals(getSurveyYear(), that.getSurveyYear());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFormId(), getSurveyYear());
    }
}
