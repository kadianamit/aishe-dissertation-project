package aishe.gov.in.mastersvo;

public class CaptchaResponse {
private String capcha;
private String data;
public String getCapcha() {
	return capcha;
}
public void setCapcha(String capcha) {
	this.capcha = capcha;
}
public String getData() {
	return data;
}
public void setData(String data) {
	this.data = data;
}
	
}
