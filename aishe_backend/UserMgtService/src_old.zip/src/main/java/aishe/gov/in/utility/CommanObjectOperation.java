package aishe.gov.in.utility;

import java.util.List;

public class CommanObjectOperation {

    public static Boolean listValidate(List<?> list) {
        if (null != list && !list.isEmpty()) {
            return true;
        }
        return false;
    }

    public static Boolean stringValidate(String obj) {
        if (null != obj && !("null".equals(obj)) && !obj.isEmpty()) {
            return true;
        }
        return false;
    }

    public static Boolean integerValidate(Integer obj) {
        if (null != obj) {
            return true;
        }
        return false;
    }

    public static Boolean booleanValidate(Boolean obj) {
        if (null != obj) {
            return true;
        }
        return false;
    }

    public static Boolean longValidate(Long obj) {
        if (null != obj) {
            return true;
        }
        return false;
    }

    public static Boolean doubleValidate(Double obj) {
        if (null != obj) {
            return true;
        }
        return false;
    }

    public static Boolean objectValidate(Object obj) {
        if (null != obj) {
            return true;
        }
        return false;
    }




}
