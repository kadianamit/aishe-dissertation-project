package aishe.gov.in.controller;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import aishe.gov.in.masterseo.CollegeEO;
import aishe.gov.in.masterseo.UniversityRef;
import aishe.gov.in.mastersvo.CollegeDeaffiliationAffiliationVO;
import aishe.gov.in.service.CollegeAffiliationDeaffiliationService;
import aishe.gov.in.service.CollegeStateDistrictService;
import aishe.gov.in.utility.AisheCodeConvertInID;
import aishe.gov.in.utility.ReturnResponse;

@RestController
public class CollegeDeaffiliationAffiliation {

    private static final Logger logger = LoggerFactory.getLogger(CollegeDeaffiliationAffiliation.class);

    @Autowired
    private AisheCodeConvertInID aisheCodeToId;

    @Autowired
    private CollegeAffiliationDeaffiliationService affiliationDeaffiliationService;

    @Autowired
    private CollegeStateDistrictService stateDistrictService;
//33947
    @PostMapping("/saveDeaffiliationAndAffiliation")
    public ResponseEntity<ReturnResponse> collegeDeaffiliationAffiliation(@RequestBody CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO) throws ParseException {
        logger.info("College Deaffiliation Affiliation controller : collegeDeaffiliationAffiliation method invoked : {}");
        if(!(deaffiliationAffiliationVO.getUsername().equals("aishe.helpdesk") && deaffiliationAffiliationVO.getSecretKey().equals("MOEDIVISION@AISHE"))){
        	 return new ResponseEntity<>(new ReturnResponse(HttpStatus.UNAUTHORIZED.value(),
                     "You Are Not Authorized."), HttpStatus.UNAUTHORIZED);
        }
        
        String collegeId = aisheCodeToId.aisheCodeToId(deaffiliationAffiliationVO.getCollegeAisheCode());
        String universityId = aisheCodeToId.aisheCodeToId(deaffiliationAffiliationVO.getUniversityAisheCode());
        CollegeEO collegeEO = affiliationDeaffiliationService.getCollegeMaster(collegeId, deaffiliationAffiliationVO.getSurveyYear());
        UniversityRef newUniversityRef = affiliationDeaffiliationService.getUniversityMaster(universityId, deaffiliationAffiliationVO.getSurveyYear());
        if (null == collegeEO) {
            return new ResponseEntity<>(new ReturnResponse(HttpStatus.NOT_FOUND.value(),
                    "College not found for AISHE code C-" + collegeId + " for survey year " + deaffiliationAffiliationVO.getSurveyYear()), HttpStatus.NOT_FOUND);
        }
        if (null == newUniversityRef) {
            return new ResponseEntity<>(new ReturnResponse(HttpStatus.NOT_FOUND.value(),
                    "University not found for AISHE code U-" + universityId + " for survey year " + deaffiliationAffiliationVO.getSurveyYear()), HttpStatus.NOT_FOUND);
        }
        UniversityRef oldUniversityRef = affiliationDeaffiliationService.getUniversityMaster(collegeEO.getUniversityId(), deaffiliationAffiliationVO.getSurveyYear());
        if (null == oldUniversityRef) {
            return new ResponseEntity<>(new ReturnResponse(HttpStatus.NOT_FOUND.value(),
                    "University not found for AISHE code U-" + oldUniversityRef.getId() + " for survey year " + deaffiliationAffiliationVO.getSurveyYear()), HttpStatus.NOT_FOUND);
        } else {
            deaffiliationAffiliationVO.setCollegeAisheCode(collegeId);
            deaffiliationAffiliationVO.setUniversityAisheCode(universityId);
            Boolean isSaved = affiliationDeaffiliationService.saveUpdateCollegeAffiliationDeaffiliation(deaffiliationAffiliationVO, collegeEO, oldUniversityRef, newUniversityRef);
            if (isSaved) {
                return new ResponseEntity<>(new ReturnResponse(HttpStatus.OK.value(), "College C-" + deaffiliationAffiliationVO.getCollegeAisheCode() + " has been successfully Deffiliated from U-"
                        + oldUniversityRef.getId() + "( " + oldUniversityRef.getName() + " , " + stateDistrictService.getDistrictByCode(oldUniversityRef.getDistrictCode()).getName() + " , "
                        + stateDistrictService.getStateByCode(oldUniversityRef.getStateCode()).getName() + " )" + " and affiliated to U-" + newUniversityRef.getId() + "( " + newUniversityRef.getName() + " , "
                        + stateDistrictService.getDistrictByCode(newUniversityRef.getDistrictCode()).getName() + " , " + stateDistrictService.getStateByCode(newUniversityRef.getStateCode()).getName() + " )"),
                        HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new ReturnResponse(HttpStatus.BAD_REQUEST.value(),
                        "Request Cannot Be Processed. Please Try Again."), HttpStatus.BAD_REQUEST);

            }
        }
    }
}
