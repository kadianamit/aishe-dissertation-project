package aishe.gov.in.masterseo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;


@Entity
@Table(name = "public.university")
public class UniversityFormEO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//private UniversityId universityID; 
	@EmbeddedId
	private UniversityEmadedPK universityPk;
	//@Column(name = "survey_year")
	//private Integer surveyYear;
	@Column(name = "name")
	private String name;	
	@Column(name = "address_line1")
	private String addressline1;
	@Column(name = "address_line2")
	private String addressline2;
	@Column(name = "city")
	private String city;
	@Column(name = "location")
	private String location;
	@Column(name = "other_speciality")
	private String otherSpeciality;
	@Column(name = "website")
	private String website;
	@Column(name = "remarks")
	private String remarks;
	@Column(name = "pin_code")
	private String pinCode;
	@Column(name = "block_city_town")
	private String blockCityTown;
	@Column(name = "area")
	private Double area;	
	@Column(name = "constructed_area")
	private Double constructedArea;
	@Column(name = "latitude")
	private Double latitude;
	@Column(name = "longitude")
	private Double longitude;
	@Column(name = "no_of_student_hostel")
	private Integer noOfHostel;
	@Column(name = "no_of_regional_centers")
	private Integer noOfRegionalCenters;	
	@Column(name = "year_of_establishment")
	private Integer establishmentYear;
	@Column(name = "year_when_declared_university")
	private Integer yearWhenDeclaredUniversity;
	@Column(name = "no_of_off_shore_center")
	private Integer noOfOffShoreCenter;	
	@Column(name = "specialized")
	private Boolean specialized;
	@Column(name = "has_other_minority_data")
	private Boolean hasOtherMinorityData;	
	@Column(name = "girl_exclusive")
	private Boolean girl_exclusive;	
	@Column(name = "staff_quarter_available")
	private Boolean haveStaffQuarter;
	@Column(name = "student_hostel_available")
	private Boolean haveHostel;	
	@Column(name = "offers_distance_programme")
	private Boolean offersDistanceProgramme;
	@Column(name = "has_faculty_regular_courses")
	private Boolean hasFacultyRegularCourses;
	@Column(name = "has_department_regular_courses")
	private Boolean hasDepartmentRegularCourses;
	@Column(name = "has_other_regular_courses")
	private Boolean hasOtherRegularCourses;
	@Column(name = "constituted_from_colleges")
	private Boolean constitutedFromColleges;
	@Column(name = "offers_scholarship")
	private Boolean offersScholarship;
	@Column(name = "offers_loan")
	private Boolean offersLoan;
	@Column(name = "is_accredited")
	private Boolean isAccredited;
	@Column(name = "is_foreign_students_enrolled")
	private Boolean isForeignStudentsEnrolled;	
	@Column(name = "off_shore_center_available")
	private Boolean offShoreCenterAvailable;	
	@Column(name = "has_fellowships")
	private Boolean hasFellowships;		
	@Column(name = "is_university_uploaded_act_statues")
	private Boolean isUniversityUploadedActStatues;
	@Column(name = "is_university_complying_rules")
	private Boolean isUniversityComplyingRules;
	@Column(name = "is_university180_actual_teaching_days")
	private Boolean isUniversity180ActualTeachingDays;
	@Column(name = "has_foreign_teachers")
	private Boolean hasForeignTeachers;
	@Column(name = "infrastructure_id")
	private Integer infrastructureId;
	@Column(name = "loan_id")
	private Integer loanId;
	@Column(name = "scholarship_id")
	private Integer scholarshipId;
	@Column(name = "fellowships_id")
	private Integer felloshipsId;
	@Column(name = "financial_income_id")
	private Integer financialIncomeId;
	@Column(name = "financial_expenditure_id")
	private Integer financialExpenditureId;
	@Column(name = "status_prior_to_establishment")
	private String statusPriorToEstablishment;
	@Column(name = "ownership_status")
	private Integer ownershipStatus;
	@Column(name = "whether_village_adopted_under_unnat_bharat")
	private Boolean whetherVillageAdoptedUnderUnnatBharat;
	@Column(name = "boys_exclusive")
	private Boolean boysExclusive;
	@Column(name = "inclusion_as_university_under_section",insertable=false ,updatable=false)
	private String inclusionAsUniversityUnderSection;
	@Column(name = "inclusion_as_university_date",insertable=false ,updatable=false)
	private Date inclusionAsUniversityDate;
	@Column(name = "placement_details_id")
	private Integer placementDetailsId;
//	@ManyToOne
//	@NotFound(action = NotFoundAction.IGNORE)
//	@JoinColumn(name = "nodal_officer_id", insertable = false, updatable = false)
//	private NodalOfficerEO nodalOfficer;
	//@ManyToOne
	//@JoinColumn(name = "staff_quarter_id", insertable = false, updatable = false)
	//private StaffQuarterEO staffQuarter;
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "district_code", insertable = false, updatable = false)
	private RefDistrict districtCode;
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "state_code", insertable = false, updatable = false)
	private RefState stateCode;
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "type_id", insertable = false, updatable = false)
	private RefUniversityType instituteType;
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "speciality_id", insertable = false, updatable = false)
	private RefSpecialityEO speciality;
	//@Transient
	//private List<StudentHostelEO> hostels;
	
	//new changes
	@Column(name = "inclusion_as_university_under_section")
	private String inclusion_as_university_under_section;
	@Column(name = "inclusion_as_university_date")
	private Date inclusion_as_university_date;
	@Column(name = "approved_intake_capacity_intl_nri_pio_students")
	private Integer approved_intake_capacity_intl_nri_pio_students;
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "placement_details_id", insertable = false, updatable = false)
	private PlacementDetails placementDetails;
	@Transient
	@NotFound(action = NotFoundAction.IGNORE)
	private String inclusionAsUniversityDateString;
	@Column(name = "is_minority_managed_institution")
	private Boolean isMinorityManagedInstitution=false;
	@Column(name = "minority_community_type")
	private Integer typeMinorityCommunityManagingId;
	@Column(name = "has_ncc_unit")
	private Boolean isNCC=false;
	@Column(name = "no_of_ncc_female")
	private Integer femaleEnrolledNCC;
	@Column(name = "no_of_ncc_total")
	private Integer totalEnrolledNCC;
	@Column(name = "has_nss")
	private Boolean isNSS=false;
	@Column(name = "no_of_nss_female")
	private Integer femaleEnrolledNSS;
	@Column(name = "no_of_nss_total")
	private Integer totalEnrolledNSS;
//	@Column(name = "no_of_student_enrolled_in_ncc")
//	private Integer studentEnrolledNCC;
//	@Column(name = "no_of_student_enrolled_in_nss")
//	private Integer studentEnrolledNSS;
	@Column(name = "ncc_own_institute_male")
	private Integer nccOwnInstituteMale;
	@Column(name = "ncc_own_institute_female")
	private Integer nccOwnInstituteFemale;
	@Column(name = "ncc_other_institute_male")
	private Integer nccOtherInstituteMale;
	@Column(name = "ncc_other_institute_female")
	private Integer nccOtherInstituteFemale;
	@Column(name = "no_of_nss_male")
	private Integer noOfNssMale;
	@Column(name = "placement_details_available")
	private Boolean placementDetailsAvailable;
	@Column(name = "block_id")
	private Integer blockId;
	@Column(name = "ulb_id")
	private Integer ulbId;
	@Column(name = "offers_private_programme")
	private Boolean programmeThroughPrivateExternal;
	public PlacementDetails getPlacementDetails() {
		return placementDetails;
	}
	public void setPlacementDetails(PlacementDetails placementDetails) {
		this.placementDetails = placementDetails;
	}
	
	public UniversityEmadedPK getUniversityPk() {
		return universityPk;
	}
	public void setUniversityPk(UniversityEmadedPK universityPk) {
		this.universityPk = universityPk;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOtherSpeciality() {
		return otherSpeciality;
	}
	public void setOtherSpeciality(String otherSpeciality) {
		this.otherSpeciality = otherSpeciality;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getBlockCityTown() {
		return blockCityTown;
	}
	public void setBlockCityTown(String blockCityTown) {
		this.blockCityTown = blockCityTown;
	}
	public Double getArea() {
		return area;
	}
	public void setArea(Double area) {
		this.area = area;
	}
	public Double getConstructedArea() {
		return constructedArea;
	}
	public void setConstructedArea(Double constructedArea) {
		this.constructedArea = constructedArea;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public Integer getNoOfRegionalCenters() {
		return noOfRegionalCenters;
	}
	public void setNoOfRegionalCenters(Integer noOfRegionalCenters) {
		this.noOfRegionalCenters = noOfRegionalCenters;
	}
	public Integer getYearWhenDeclaredUniversity() {
		return yearWhenDeclaredUniversity;
	}
	public void setYearWhenDeclaredUniversity(Integer yearWhenDeclaredUniversity) {
		this.yearWhenDeclaredUniversity = yearWhenDeclaredUniversity;
	}
	public Integer getNoOfOffShoreCenter() {
		return noOfOffShoreCenter;
	}
	public void setNoOfOffShoreCenter(Integer noOfOffShoreCenter) {
		this.noOfOffShoreCenter = noOfOffShoreCenter;
	}
	public Boolean getSpecialized() {
		return specialized;
	}
	public void setSpecialized(Boolean specialized) {
		this.specialized = specialized;
	}
	public Boolean getHasOtherMinorityData() {
		return hasOtherMinorityData;
	}
	public void setHasOtherMinorityData(Boolean hasOtherMinorityData) {
		this.hasOtherMinorityData = hasOtherMinorityData;
	}
	public Integer getEstablishmentYear() {
		return establishmentYear;
	}
	public void setEstablishmentYear(Integer establishmentYear) {
		this.establishmentYear = establishmentYear;
	}
	public Boolean getGirl_exclusive() {
		return girl_exclusive;
	}
	public void setGirl_exclusive(Boolean girl_exclusive) {
		this.girl_exclusive = girl_exclusive;
	}
	public Boolean getOffersDistanceProgramme() {
		return offersDistanceProgramme;
	}
	public void setOffersDistanceProgramme(Boolean offersDistanceProgramme) {
		this.offersDistanceProgramme = offersDistanceProgramme;
	}
	public Boolean getHasFacultyRegularCourses() {
		return hasFacultyRegularCourses;
	}
	public void setHasFacultyRegularCourses(Boolean hasFacultyRegularCourses) {
		this.hasFacultyRegularCourses = hasFacultyRegularCourses;
	}
	public Boolean getHasDepartmentRegularCourses() {
		return hasDepartmentRegularCourses;
	}
	public void setHasDepartmentRegularCourses(Boolean hasDepartmentRegularCourses) {
		this.hasDepartmentRegularCourses = hasDepartmentRegularCourses;
	}
	public Boolean getHasOtherRegularCourses() {
		return hasOtherRegularCourses;
	}
	public void setHasOtherRegularCourses(Boolean hasOtherRegularCourses) {
		this.hasOtherRegularCourses = hasOtherRegularCourses;
	}
	public Boolean getConstitutedFromColleges() {
		return constitutedFromColleges;
	}
	public void setConstitutedFromColleges(Boolean constitutedFromColleges) {
		this.constitutedFromColleges = constitutedFromColleges;
	}
	public Boolean getOffersScholarship() {
		return offersScholarship;
	}
	public void setOffersScholarship(Boolean offersScholarship) {
		this.offersScholarship = offersScholarship;
	}
	public Boolean getOffersLoan() {
		return offersLoan;
	}
	public void setOffersLoan(Boolean offersLoan) {
		this.offersLoan = offersLoan;
	}
	public Boolean getIsAccredited() {
		return isAccredited;
	}
	public void setIsAccredited(Boolean isAccredited) {
		this.isAccredited = isAccredited;
	}
	public Boolean getIsForeignStudentsEnrolled() {
		return isForeignStudentsEnrolled;
	}
	public void setIsForeignStudentsEnrolled(Boolean isForeignStudentsEnrolled) {
		this.isForeignStudentsEnrolled = isForeignStudentsEnrolled;
	}
	public Boolean getOffShoreCenterAvailable() {
		return offShoreCenterAvailable;
	}
	public void setOffShoreCenterAvailable(Boolean offShoreCenterAvailable) {
		this.offShoreCenterAvailable = offShoreCenterAvailable;
	}
	public Boolean getHasFellowships() {
		return hasFellowships;
	}
	public void setHasFellowships(Boolean hasFellowships) {
		this.hasFellowships = hasFellowships;
	}
	public Boolean getIsUniversityUploadedActStatues() {
		return isUniversityUploadedActStatues;
	}
	public void setIsUniversityUploadedActStatues(Boolean isUniversityUploadedActStatues) {
		this.isUniversityUploadedActStatues = isUniversityUploadedActStatues;
	}
	public Boolean getIsUniversityComplyingRules() {
		return isUniversityComplyingRules;
	}
	public void setIsUniversityComplyingRules(Boolean isUniversityComplyingRules) {
		this.isUniversityComplyingRules = isUniversityComplyingRules;
	}
	public Boolean getIsUniversity180ActualTeachingDays() {
		return isUniversity180ActualTeachingDays;
	}
	public void setIsUniversity180ActualTeachingDays(Boolean isUniversity180ActualTeachingDays) {
		this.isUniversity180ActualTeachingDays = isUniversity180ActualTeachingDays;
	}
	public Integer getInfrastructureId() {
		return infrastructureId;
	}
	public void setInfrastructureId(Integer infrastructureId) {
		this.infrastructureId = infrastructureId;
	}
	public Integer getLoanId() {
		return loanId;
	}
	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}
	public Integer getScholarshipId() {
		return scholarshipId;
	}
	public void setScholarshipId(Integer scholarshipId) {
		this.scholarshipId = scholarshipId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public RefDistrict getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(RefDistrict districtCode) {
		this.districtCode = districtCode;
	}
	public RefState getStateCode() {
		return stateCode;
	}
	public void setStateCode(RefState stateCode) {
		this.stateCode = stateCode;
	}
	
	public RefUniversityType getInstituteType() {
		return instituteType;
	}
	public void setInstituteType(RefUniversityType instituteType) {
		this.instituteType = instituteType;
	}
	public RefSpecialityEO getSpeciality() {
		return speciality;
	}
	public void setSpeciality(RefSpecialityEO speciality) {
		this.speciality = speciality;
	}
	public Integer getFelloshipsId() {
		return felloshipsId;
	}
	public void setFelloshipsId(Integer felloshipsId) {
		this.felloshipsId = felloshipsId;
	}
	public Integer getFinancialIncomeId() {
		return financialIncomeId;
	}
	public void setFinancialIncomeId(Integer financialIncomeId) {
		this.financialIncomeId = financialIncomeId;
	}
	public Integer getFinancialExpenditureId() {
		return financialExpenditureId;
	}
	public void setFinancialExpenditureId(Integer financialExpenditureId) {
		this.financialExpenditureId = financialExpenditureId;
	}
	public Integer getNoOfHostel() {
		return noOfHostel;
	}
	public void setNoOfHostel(Integer noOfHostel) {
		this.noOfHostel = noOfHostel;
	}
	public Boolean getHaveStaffQuarter() {
		return haveStaffQuarter;
	}
	public void setHaveStaffQuarter(Boolean haveStaffQuarter) {
		this.haveStaffQuarter = haveStaffQuarter;
	}
	public Boolean getHaveHostel() {
		return haveHostel;
	}
	public void setHaveHostel(Boolean haveHostel) {
		this.haveHostel = haveHostel;
	}
	public Boolean getHasForeignTeachers() {
		return hasForeignTeachers;
	}
	public void setHasForeignTeachers(Boolean hasForeignTeachers) {
		this.hasForeignTeachers = hasForeignTeachers;
	}
	public String getInclusion_as_university_under_section() {
		return inclusion_as_university_under_section;
	}
	public void setInclusion_as_university_under_section(String inclusion_as_university_under_section) {
		this.inclusion_as_university_under_section = inclusion_as_university_under_section;
	}
	public Date getInclusion_as_university_date() {
		return inclusion_as_university_date;
	}
	public void setInclusion_as_university_date(Date inclusion_as_university_date) {
		this.inclusion_as_university_date = inclusion_as_university_date;
	}
	public Integer getApproved_intake_capacity_intl_nri_pio_students() {
		return approved_intake_capacity_intl_nri_pio_students;
	}
	public void setApproved_intake_capacity_intl_nri_pio_students(Integer approved_intake_capacity_intl_nri_pio_students) {
		this.approved_intake_capacity_intl_nri_pio_students = approved_intake_capacity_intl_nri_pio_students;
	}
	public String getStatusPriorToEstablishment() {
		return statusPriorToEstablishment;
	}
	public void setStatusPriorToEstablishment(String statusPriorToEstablishment) {
		this.statusPriorToEstablishment = statusPriorToEstablishment;
	}
	public Integer getOwnershipStatus() {
		return ownershipStatus;
	}
	public void setOwnershipStatus(Integer ownershipStatus) {
		this.ownershipStatus = ownershipStatus;
	}
	public Boolean getWhetherVillageAdoptedUnderUnnatBharat() {
		return whetherVillageAdoptedUnderUnnatBharat;
	}
	public void setWhetherVillageAdoptedUnderUnnatBharat(Boolean whetherVillageAdoptedUnderUnnatBharat) {
		this.whetherVillageAdoptedUnderUnnatBharat = whetherVillageAdoptedUnderUnnatBharat;
	}
	public Boolean getBoysExclusive() {
		return boysExclusive;
	}
	public void setBoysExclusive(Boolean boysExclusive) {
		this.boysExclusive = boysExclusive;
	}
	public String getInclusionAsUniversityUnderSection() {
		return inclusionAsUniversityUnderSection;
	}
	public void setInclusionAsUniversityUnderSection(String inclusionAsUniversityUnderSection) {
		this.inclusionAsUniversityUnderSection = inclusionAsUniversityUnderSection;
	}
	public Date getInclusionAsUniversityDate() {
		return inclusionAsUniversityDate;
	}
	public void setInclusionAsUniversityDate(Date inclusionAsUniversityDate) {
		this.inclusionAsUniversityDate = inclusionAsUniversityDate;
	}
	public Integer getPlacementDetailsId() {
		return placementDetailsId;
	}
	public void setPlacementDetailsId(Integer placementDetailsId) {
		this.placementDetailsId = placementDetailsId;
	}
	public String getInclusionAsUniversityDateString() {
		return inclusionAsUniversityDateString;
	}
	public void setInclusionAsUniversityDateString(String inclusionAsUniversityDateString) {
		this.inclusionAsUniversityDateString = inclusionAsUniversityDateString;
	}
	public Boolean getIsMinorityManagedInstitution() {
		return isMinorityManagedInstitution;
	}
	public void setIsMinorityManagedInstitution(Boolean isMinorityManagedInstitution) {
		this.isMinorityManagedInstitution = isMinorityManagedInstitution;
	}
	public Integer getTypeMinorityCommunityManagingId() {
		return typeMinorityCommunityManagingId;
	}
	public void setTypeMinorityCommunityManagingId(Integer typeMinorityCommunityManagingId) {
		this.typeMinorityCommunityManagingId = typeMinorityCommunityManagingId;
	}
	public Boolean getIsNCC() {
		return isNCC;
	}
	public void setIsNCC(Boolean isNCC) {
		this.isNCC = isNCC;
	}
	public Integer getFemaleEnrolledNCC() {
		return femaleEnrolledNCC;
	}
	public void setFemaleEnrolledNCC(Integer femaleEnrolledNCC) {
		this.femaleEnrolledNCC = femaleEnrolledNCC;
	}
	public Integer getTotalEnrolledNCC() {
		return totalEnrolledNCC;
	}
	public void setTotalEnrolledNCC(Integer totalEnrolledNCC) {
		this.totalEnrolledNCC = totalEnrolledNCC;
	}
	public Boolean getIsNSS() {
		return isNSS;
	}
	public void setIsNSS(Boolean isNSS) {
		this.isNSS = isNSS;
	}
	public Integer getFemaleEnrolledNSS() {
		return femaleEnrolledNSS;
	}
	public void setFemaleEnrolledNSS(Integer femaleEnrolledNSS) {
		this.femaleEnrolledNSS = femaleEnrolledNSS;
	}
	public Integer getTotalEnrolledNSS() {
		return totalEnrolledNSS;
	}
	public void setTotalEnrolledNSS(Integer totalEnrolledNSS) {
		this.totalEnrolledNSS = totalEnrolledNSS;
	}
	
	public Integer getNccOwnInstituteFemale() {
		return nccOwnInstituteFemale;
	}
	public void setNccOwnInstituteFemale(Integer nccOwnInstituteFemale) {
		this.nccOwnInstituteFemale = nccOwnInstituteFemale;
	}
	public Integer getNccOtherInstituteFemale() {
		return nccOtherInstituteFemale;
	}
	public void setNccOtherInstituteFemale(Integer nccOtherInstituteFemale) {
		this.nccOtherInstituteFemale = nccOtherInstituteFemale;
	}
	public Integer getNccOwnInstituteMale() {
		return nccOwnInstituteMale;
	}
	public void setNccOwnInstituteMale(Integer nccOwnInstituteMale) {
		this.nccOwnInstituteMale = nccOwnInstituteMale;
	}
	public Integer getNccOtherInstituteMale() {
		return nccOtherInstituteMale;
	}
	public void setNccOtherInstituteMale(Integer nccOtherInstituteMale) {
		this.nccOtherInstituteMale = nccOtherInstituteMale;
	}
	public Integer getNoOfNssMale() {
		return noOfNssMale;
	}
	public void setNoOfNssMale(Integer noOfNssMale) {
		this.noOfNssMale = noOfNssMale;
	}
	public Boolean getPlacementDetailsAvailable() {
		return placementDetailsAvailable;
	}
	public void setPlacementDetailsAvailable(Boolean placementDetailsAvailable) {
		this.placementDetailsAvailable = placementDetailsAvailable;
	}
	public Integer getBlockId() {
		return blockId;
	}
	public void setBlockId(Integer blockId) {
		this.blockId = blockId;
	}
	public Integer getUlbId() {
		return ulbId;
	}
	public void setUlbId(Integer ulbId) {
		this.ulbId = ulbId;
	}
	public Boolean getProgrammeThroughPrivateExternal() {
		return programmeThroughPrivateExternal;
	}
	public void setProgrammeThroughPrivateExternal(Boolean programmeThroughPrivateExternal) {
		this.programmeThroughPrivateExternal = programmeThroughPrivateExternal;
	}	
}