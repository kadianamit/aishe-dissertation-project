package aishe.gov.in.dao;

import java.sql.Connection;

public interface ReportGenerationDao {

	public Connection findConnection();
} 
