package aishe.gov.in.utility;

import aishe.gov.in.mastersvo.AfiiliatedWithUniversityCount;
import aishe.gov.in.mastersvo.SelectOptionVO;
import aishe.gov.in.service.RemunerationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RemunerationAmountCalculator {

    @Autowired
    private AisheCodeConvertInID convert;
    @Autowired
    private RemunerationService remunerationService;

    public Double remunerationAmount(String aisheCode, Integer surveyYear) {
        String splitedAisheCode[] = convert.aisheCodeToArray(aisheCode);
        Double amt = null;
        switch (splitedAisheCode[0]) {
            case "C": {
                List<SelectOptionVO> optionVOS = remunerationService.checkEligibility(aisheCode, surveyYear);
                if (CommanObjectOperation.listValidate(optionVOS))
                    amt = Double.valueOf(5000);
            }
            case "S": {
                List<SelectOptionVO> optionVOS = remunerationService.checkEligibility(aisheCode, surveyYear);
                if (CommanObjectOperation.listValidate(optionVOS))
                    amt = Double.valueOf(2000);
            }
            case "U": {
                List<SelectOptionVO> optionVOS = remunerationService.checkEligibility(aisheCode, surveyYear);
                if (CommanObjectOperation.listValidate(optionVOS)) {
                    amt = Double.valueOf(10000);
                } else {
                    AfiiliatedWithUniversityCount afiiliatedWithUniversityCount = remunerationService.getAffiliatedCollegeCount(splitedAisheCode[1], surveyYear);
                    if (afiiliatedWithUniversityCount.getTotalFormUploadedAffiliatedCollege().intValue() >= 50
                            && 199 <= afiiliatedWithUniversityCount.getTotalFormUploadedAffiliatedCollege().intValue()) {
                        amt = Double.valueOf(10000);
                    } else if (afiiliatedWithUniversityCount.getTotalFormUploadedAffiliatedCollege().intValue() >= 200
                            && 499 <= afiiliatedWithUniversityCount.getTotalFormUploadedAffiliatedCollege().intValue()) {
                        amt = Double.valueOf(15000);
                    } else if (afiiliatedWithUniversityCount.getTotalFormUploadedAffiliatedCollege().intValue() >= 500) {
                        amt = Double.valueOf(20000);
                    }
                }
            }
        }
        return amt;
    }
}
