package aishe.gov.in.masterseo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@AllArgsConstructor
@RequiredArgsConstructor
@Setter
@Getter
@Entity
@Builder
@Table(name = "remuneration_statement_detail_transaction_log")
public class RemunerationStatementDetailTransactionLogEO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "form_upload_id")
    private Integer formUploadId;
    @Column(name = "user_id")
    private String userId;
    @Column(name = "status_id")
    private Integer statusId;
    @Column(name = "timestamp")
    private Timestamp timestamp;

    @Column(name = "ip_address")
    private String ipAddress;
}
