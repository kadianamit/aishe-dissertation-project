package aishe.gov.in.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import aishe.gov.in.enums.SortBy;
import aishe.gov.in.masterseo.ApproveDisapproveUserDTO;
import aishe.gov.in.masterseo.ApproveUserDTO;
import aishe.gov.in.masterseo.InstituteDetailEO;
import aishe.gov.in.masterseo.UserActionLog;
import aishe.gov.in.masterseo.UserMasterDetailEO;
import aishe.gov.in.masterseo.UserMasterDetailStateEO;
import aishe.gov.in.masterseo.UserMasterEO;
import aishe.gov.in.masterseo.UserMasterLogDetailEO;
import aishe.gov.in.masterseo.UserMasterNewEO;
import aishe.gov.in.masterseo.UserMasterRequestDetailEO;
import aishe.gov.in.masterseo.UserRegistrationDetailEO;
import aishe.gov.in.masterseo.UserRegistrationUpdatedDetailEO;
import aishe.gov.in.masterseo.WebDcfPersonDetailsEO;
import aishe.gov.in.mastersvo.PersonDetailsEmadedPK;
import aishe.gov.in.mastersvo.RegisteredUserDTO;
import aishe.gov.in.utility.DateUtils;
import aishe.gov.in.utility.EncryptionDecryptionUtil;

@Repository
public class RegisterationDaoImpl implements RegisterationDao {
  //  @Autowired
  //  private NullValueHandler handler;
    @Autowired
    private SessionFactory sessionFactory;
    @Autowired
    BCryptPasswordEncoder bcrypt;
    private static final Logger logger = LoggerFactory.getLogger(RegisterationDaoImpl.class);

    @Override
    public UserMasterNewEO saveUpdateRegistration(UserMasterNewEO userMasterEO) {
        logger.info("RegisterationDaoImpl : saveUpdateRegistration method invoked :");
        Session session = sessionFactory.openSession();
        Session session1 = sessionFactory.openSession();
        Transaction tx = null;
        UserMasterNewEO checkForEmail = (UserMasterNewEO) session1.get(UserMasterNewEO.class, userMasterEO.getUserId());
        if (userMasterEO.getEmailVerified().equals(false)) {
            if (!userMasterEO.getEmail().equals(checkForEmail.getEmail())) {
                return null;
            }
        }
        if (userMasterEO.getMobileVerified().equals(false)) {
            if (!userMasterEO.getMobile().toString().equals(checkForEmail.getMobile().toString())) {
                return null;
            }
        }
        try {
        	
            tx = session.beginTransaction();
            session.update(userMasterEO);
            if(userMasterEO.getAisheCode()!=null) {
            String[] splitted = userMasterEO.getAisheCode().trim().split("\\s*-\\s*");
	        String instituteId = splitted[1];
	        String instituteType = splitted[0];
	        
	        LocalDateTime currTime = DateUtils.obtainCurrentTimeStamp();
	        List<Integer> surveyYear = ((List<Integer>) session1.createNativeQuery("select survey_year from public.survey_master where"
					+ " start_date<=cast('"+currTime+"' as timestamp with time zone) and end_date>cast('"+currTime+"' as timestamp with time zone) "
							+ " or end_date is null order by survey_year asc").getResultList());
           if(!surveyYear.isEmpty()) {
	        WebDcfPersonDetailsEO nodal = findNodalOfficerDetail(instituteId,instituteType,"NO",surveyYear.get(0));
	        WebDcfPersonDetailsEO nodals = new WebDcfPersonDetailsEO();
            if(nodal==null) {
            PersonDetailsEmadedPK pk = new PersonDetailsEmadedPK();
			if(surveyYear.get(0)>2022) {
				pk.setSurveyYear(2022);
			}else {
				pk.setSurveyYear(surveyYear.get(0));
			}
			pk.setAisheCode(instituteId);
			pk.setInstituteType(instituteType);
			pk.setOfficerType("NO");
			nodals.setUniversityPk(pk);
			nodals.setOfficerEmail(userMasterEO.getEmail());
			nodals.setOfficerMobile(String.valueOf(userMasterEO.getMobile()));
			if(userMasterEO.getMiddleName()==null) {
				userMasterEO.setMiddleName("");
			}
			if(userMasterEO.getLastName()==null) {
				userMasterEO.setLastName("");
			}
			nodals.setOfficerName(userMasterEO.getNodalOfficerName());//userMasterEO.getFirstName() +" "+ userMasterEO.getMiddleName() + " " + userMasterEO.getLastName());
			nodals.setOfficerTelephone(userMasterEO.getPhoneLandline());
			
			String designation = (String) session1.createNativeQuery("select officer_designation from webdcf.person_details_survey where aishe_code ='"+instituteId+"' and "
			 		+ "survey_year in (select max(survey_year) from \r\n"
			 		+ "form_upload where university_id ='"+instituteId+"') and inst_type ='"+instituteType+"' AND officer_type ='NO'").uniqueResult();
		    if(nodal==null) {
		    	nodals.setOfficerDesignation(designation);
		    }
			session.saveOrUpdate(nodals);
            }else {
            	PersonDetailsEmadedPK pk = new PersonDetailsEmadedPK();
      			
            	if(surveyYear.get(0)>2022) {
      				pk.setSurveyYear(2022);
      			}else {
      				pk.setSurveyYear(surveyYear.get(0));
      			}
      			pk.setAisheCode(instituteId);
      			pk.setInstituteType(instituteType);
      			pk.setOfficerType("NO");
      			nodals.setUniversityPk(pk);
      			nodals.setOfficerEmail(userMasterEO.getEmail());
      			nodals.setOfficerMobile(String.valueOf(userMasterEO.getMobile()));
      			
      			if(userMasterEO.getMiddleName()==null) {
      				userMasterEO.setMiddleName("");
      			}
      			if(userMasterEO.getLastName()==null) {
      				userMasterEO.setLastName("");
      			}
      			nodals.setOfficerName(userMasterEO.getNodalOfficerName());
      			//nodals.setOfficerName(userMasterEO.getFirstName() +" "+ userMasterEO.getMiddleName() + " " + userMasterEO.getLastName());
      			nodals.setOfficerTelephone(userMasterEO.getPhoneLandline());
      	
      			nodals.setOfficerDesignation(nodal.getOfficerDesignation());
            	session.update(nodals);
            }
           }}
            //}
            tx.commit();
            return userMasterEO;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction " + trEx.getMessage());
                e.printStackTrace();
            }
        } finally {
            session.close();
            session1.close();
        }
        return null;
    }

    private WebDcfPersonDetailsEO findNodalOfficerDetail(String instituteId, String instituteType, String officerType,
			int surveyYear) {
         Session session = sessionFactory.openSession();
         try {
             CriteriaBuilder builder = session.getCriteriaBuilder();
             CriteriaQuery<WebDcfPersonDetailsEO> query = builder
                     .createQuery(WebDcfPersonDetailsEO.class);
             Root<WebDcfPersonDetailsEO> allData = query.from(WebDcfPersonDetailsEO.class);
             query.where(builder.and(builder.equal(allData.get("universityPk").get("aisheCode"), instituteId),
                     builder.equal(allData.get("universityPk").get("surveyYear"), 2022)
                     ,builder.equal(allData.get("universityPk").get("officerType"), "NO"),
                     builder.equal(allData.get("universityPk").get("instituteType"), instituteType
                     		)));
             WebDcfPersonDetailsEO university = session.createQuery(query).getSingleResult();
             return university;
         } catch (Exception e) {
         } finally {
             session.close();
         }
         return null;
     }

	@Override
    public UserMasterEO getUserRegistration(String userId) {
        logger.info("RegisterationDaoImpl : getUserRegistration method invoked :");
        Session session = sessionFactory.openSession();
        try {
            //String userid = userId.toLowerCase();
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.append(" from UserMasterEO where userId= :userId and isApproved=1");
            Query query = session.createQuery(queryBuilder.toString());
            query.setParameter("userId", userId);
            List<UserMasterEO> list = query.getResultList();

//        CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery<UserMasterEO> criteriaQuery = builder.createQuery(UserMasterEO.class);
//        Root<UserMasterEO> root = criteriaQuery.from(UserMasterEO.class);
//        List<Predicate> predicates = new ArrayList<Predicate>();
//            if (userId != null) {
//                predicates.add(builder.equal(root.l("userId"), userId));
//                predicates.add(builder.equal(root.get("isApproved"), 1));
//            }
//            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
//            Query<UserMasterEO> q = session.createQuery(criteriaQuery);
//            List<UserMasterEO> list = q.getResultList();
            Integer lsy = null;
            Integer minlsy = null;
            if (list.get(0).getAisheCode() != null) {
                String aisheCode = list.get(0).getAisheCode();
                String[] splitted = aisheCode.trim().split("\\s*-\\s*");
                String instituteType = splitted[0];
                String instituteId = splitted[1];
                Integer openSurvey = null;
                openSurvey = (Integer) session.createNativeQuery("select max(survey_year) from public.survey_master where end_date>now()").uniqueResult();
                if (openSurvey == null) {
                    openSurvey = 0;
                }
                if (instituteType.equals("C")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where college_institution_id = '" + instituteId + "'"
                            + " and institute_type ='C' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where college_institution_id = '" + instituteId + "'"
                                + " and institute_type ='C' and survey_year<" + lsy + " ").uniqueResult();
                    }
                }
                if (instituteType.equals("S")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where standalone_institution_id = '" + instituteId + "'"
                            + " and institute_type ='S' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where standalone_institution_id = '" + instituteId + "'"
                                + " and institute_type ='S' and survey_year<" + lsy + "").uniqueResult();
                    }
                }
                if (instituteType.equals("U")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where university_id = '" + instituteId + "'"
                            + " and institute_type ='U' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where university_id = '" + instituteId + "'"
                                + " and institute_type ='U' and survey_year<" + lsy + "").uniqueResult();
                    }
                }
//                if(lsy==null) {
//                	lsy=openSurvey;
//                }
            }
            UserMasterEO usermaster = new UserMasterEO();
            BeanUtils.copyProperties(list.get(0), usermaster);
            usermaster.setLSY(lsy);
            usermaster.setMinlsy(minlsy);
            if (list.size() > 0) {
                return usermaster;//list.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;

    }
	
	@Override
    public UserMasterEO getUserRegistration1(String userId) {
        logger.info("RegisterationDaoImpl : getUserRegistration method invoked :");
        Session session = sessionFactory.openSession();
        try {
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.append(" from UserMasterEO where userId= :userId");
            Query query = session.createQuery(queryBuilder.toString());
            query.setParameter("userId", userId);
            List<UserMasterEO> list = query.getResultList();
            Integer lsy = null;
            Integer minlsy = null;
            if (list.get(0).getAisheCode() != null) {
                String aisheCode = list.get(0).getAisheCode();
                String[] splitted = aisheCode.trim().split("\\s*-\\s*");
                String instituteType = splitted[0];
                String instituteId = splitted[1];
                Integer openSurvey = null;
                openSurvey = (Integer) session.createNativeQuery("select max(survey_year) from public.survey_master where end_date>now()").uniqueResult();
                if (openSurvey == null) {
                    openSurvey = 0;
                }
                if (instituteType.equals("C")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where college_institution_id = '" + instituteId + "'"
                            + " and institute_type ='C' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where college_institution_id = '" + instituteId + "'"
                                + " and institute_type ='C' and survey_year<" + lsy + " ").uniqueResult();
                    }
                }
                if (instituteType.equals("S")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where standalone_institution_id = '" + instituteId + "'"
                            + " and institute_type ='S' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where standalone_institution_id = '" + instituteId + "'"
                                + " and institute_type ='S' and survey_year<" + lsy + "").uniqueResult();
                    }
                }
                if (instituteType.equals("U")) {
                    lsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where university_id = '" + instituteId + "'"
                            + " and institute_type ='U' and survey_year<" + openSurvey + "").uniqueResult();
                    if (lsy != null) {
                        minlsy = (Integer) session.createNativeQuery("select max(survey_year) from form_upload where university_id = '" + instituteId + "'"
                                + " and institute_type ='U' and survey_year<" + lsy + "").uniqueResult();
                    }
                }
//                if(lsy==null) {
//                	lsy=openSurvey;
//                }
            }
            UserMasterEO usermaster = new UserMasterEO();
            BeanUtils.copyProperties(list.get(0), usermaster);
            usermaster.setLSY(lsy);
            usermaster.setMinlsy(minlsy);
            if(usermaster.getAisheCode()!=null) {
            	  InstituteDetailEO instituteDetail = getInstituteDetail(usermaster.getAisheCode());
                  usermaster.setFirstName(instituteDetail.getNodalOfficerName());
                  usermaster.setEmail(instituteDetail.getNodalOfficerEmail());
                  usermaster.setMobile(instituteDetail.getNodalOfficerMobile());
            }
            if (list.size() > 0) {
                return usermaster;//list.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;

    }
	
	
    @Override
    public UserMasterDetailEO getUserByUserId(String userId) {
        logger.info("RegisterationDaoImpl : getUserRegistration method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<UserMasterDetailEO> criteriaQuery = builder.createQuery(UserMasterDetailEO.class);
            Root<UserMasterDetailEO> root = criteriaQuery.from(UserMasterDetailEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();
            if (userId != null) {
                predicates.add(builder.equal(root.get("userId"), userId));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<UserMasterDetailEO> q = session.createQuery(criteriaQuery);
            List<UserMasterDetailEO> list = q.getResultList();
            if (list.size() > 0) {
                return list.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public UserMasterDetailEO getUser(ApproveUserDTO approveUserDTO) {
        logger.info("RegisterationDaoImpl : getUserRegistration method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<UserMasterDetailEO> criteriaQuery = builder.createQuery(UserMasterDetailEO.class);
            Root<UserMasterDetailEO> root = criteriaQuery.from(UserMasterDetailEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();
            if (approveUserDTO.getAisheCode() != null) {
                predicates.add(builder.equal(root.get("aisheCode"), approveUserDTO.getAisheCode()));
            }
            if (approveUserDTO.getRoleId() != null) {
                predicates.add(builder.equal(root.get("roleId"), approveUserDTO.getRoleId()));
            }
            predicates.add(builder.equal(root.get("isApproved"), 1));
            predicates.add(builder.equal(root.get("statusId"), 2));
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<UserMasterDetailEO> q = session.createQuery(criteriaQuery);
            List<UserMasterDetailEO> list = q.getResultList();
            if (list.size() > 0) {
                return list.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;

    }

    @Override
    public UserMasterDetailEO save(UserMasterDetailEO UserMasterDetailEO) {
        logger.info("RegisterationDaoImpl : saveUpdateRegistration method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.update(UserMasterDetailEO);
            tx.commit();
            return UserMasterDetailEO;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction " + trEx.getMessage());
                e.printStackTrace();
            }
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public Boolean deleteUser(UserMasterDetailEO masterEO) {
        logger.info("RegisterationDaoImpl : deleteUser method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.delete(masterEO);
            tx.commit();
            return true;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction " + trEx.getMessage());
                e.printStackTrace();
            }
        } finally {
            session.close();
        }
        return false;
    }

    @Override
    public List<UserMasterDetailStateEO> getUserByCondition(Integer roleId, String aisheCode, Integer userStatus, String stateCode, String UniversityId, Integer deoRoleId, Boolean isApproved) {
        logger.info("RegisterationDaoImpl : getUserRegistration method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<UserMasterDetailStateEO> criteriaQuery = builder.createQuery(UserMasterDetailStateEO.class);
            Root<UserMasterDetailStateEO> root = criteriaQuery.from(UserMasterDetailStateEO.class);
            List<Predicate> predicates = new ArrayList<>();
            if (roleId != null) {
                predicates.add(builder.equal(root.get("roleId"), roleId));
            }
            if (aisheCode != null) {
                predicates.add(builder.equal(root.get("aisheCode"), aisheCode));
            }
            if (userStatus != null) {
                predicates.add(builder.equal(root.get("statusId"), userStatus));
            }
            if (stateCode != null) {
                predicates.add(builder.equal(root.get("state").get("id"), stateCode));
            }

            if (deoRoleId != null) {
                predicates.add(builder.equal(root.get("deoUserType"), deoRoleId));
            }
            if (isApproved != null) {
                predicates.add(builder.equal(root.get("isApproved"), isApproved == true ? 1 : 0));
            }
            if (UniversityId != null) {
                predicates.add(builder.equal(root.get("stateLevelBody"), UniversityId));
            }


            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<UserMasterDetailStateEO> q = session.createQuery(criteriaQuery);
            List<UserMasterDetailStateEO> list = q.getResultList();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;

    }

    @Override
    public List<RegisteredUserDTO> getRegisteredUser(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, SortBy sortBy, String instituteType, /*int page, int pageSize,*/ String fromDate, String toDate, String searchText) {
        logger.info("RegisterationDaoImpl : getRegisteredUser method invoked :");
        Session session = sessionFactory.openSession();
        List<RegisteredUserDTO> userDTOS = new ArrayList<>();
        StringBuilder queryBuilder = new StringBuilder();
        try {
            if (null != instituteType) {
                if (instituteType.equalsIgnoreCase("C")) {
                    if (formUploadStatus != null) {
                        if (true == formUploadStatus) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COLLEGE_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FROM_UPLOAD_COLLEGE_WITHOUT_SURVEY);
                            }
                        } else {
                            if (surveyYear != null)
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_COLLEGE);
                        }

                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.COLLEGE_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.COLLEGE_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("S")) {
                    if (formUploadStatus != null) {
                        if (true == formUploadStatus) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_STANDALONE_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_STANDALONE_WITHOUT_SURVEY);
                            }
                        } else {
                            if (surveyYear != null)
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_STANDALONE);
                        }
                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.STANDALONE_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.STANDALONE_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("U")) {
                    if (formUploadStatus != null) {
                        if (true == formUploadStatus) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UNIVERSITY_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UNIVERSITY_WITHOUT_SURVEY);
                            }
                        } else {
                            queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_UNIVERSITY);
                        }
                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.UNIVERSITY_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.UNIVERSITY_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("ALL")) {
                    if (null == formUploadStatus) {
                        queryBuilder.append(NativeQuerySystem.OTHERS_USER);
                    }
                }
            } else {
                if (null == formUploadStatus) {
                    queryBuilder = new StringBuilder();
                    queryBuilder.append(NativeQuerySystem.OTHERS_USER);
                }
            }
            //if (formUploadStatus != null && formUploadStatus == false)
            queryBuilder = new StringBuilder(fillParameter(queryBuilder.toString(), surveyYear, formUploadStatus));
            String finalQuery = setParameterInQuery(queryBuilder.toString(), roleId, surveyYear, userStatus, deoRoleId, dcfStatus, formUploadStatus, stateCode, universityId, aisheCode, isApproved, instituteType, fromDate, toDate, searchText);
            Query query = session.createNativeQuery(finalQuery + " order by um.user_id");
            query.setParameter("roleId", roleId);
            /*query.setFirstResult((page - 1) * pageSize);
            query.setMaxResults(pageSize);*/

            @SuppressWarnings("unchecked")
            List<Object[]> userListData = (List<Object[]>) query.getResultList();
            userDTOS = bindObjectInTODto(userListData, userDTOS, formUploadStatus, surveyYear);
            return userDTOS;
        } catch (Exception e) {
        } finally {
            session.close();
        }
        return userDTOS;
    }

    private String getNameByNative(String query) {
        logger.info("MasterDataDaoImpl : getNameByNative method invoked :");

        Session session1 = sessionFactory.openSession();
        Transaction tx = null;
        try {
            return String.valueOf(session1.createNativeQuery(query).uniqueResult());
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                e.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            session1.close();
        }
        return null;
    }

    private List<RegisteredUserDTO> bindObjectInTODto(List<Object[]> userListData, List<RegisteredUserDTO> userDTOS, Boolean formUploadStatus, Integer surveyYear) {
        for (Object[] object : userListData) {
            RegisteredUserDTO registeredUserDTO = new RegisteredUserDTO();
            if (object[0] != null) {
                registeredUserDTO.setUserId(object[0].toString());
                //examinationResult.setRequestIdOrAisheCode(object[0].toString());
            }
            if (object[1] != null) {
                registeredUserDTO.setRoleId(Integer.valueOf(object[1].toString()));
                // examinationResult.setSurveyYear(Integer.parseInt(object[1].toString()));
            }
            if (object[2] != null) {
                registeredUserDTO.setFirstName(object[2].toString());
                registeredUserDTO.setFullName(registeredUserDTO.getFirstName());
            }
            if (object[3] != null) {
                registeredUserDTO.setMiddleName(object[3].toString());
                registeredUserDTO.setFullName(registeredUserDTO.getFullName() + " " + registeredUserDTO.getMiddleName());
            }
            if (object[4] != null) {
                registeredUserDTO.setLastName(object[4].toString());
                registeredUserDTO.setFullName(registeredUserDTO.getFullName() + " " + registeredUserDTO.getLastName());
            }
            if (object[5] != null) {
                registeredUserDTO.setStateName(object[5].toString());
            }
            if (object[6] != null) {
                registeredUserDTO.setIsApproved(Integer.valueOf(object[6].toString()));
            }
            if (object[7] != null) {
                registeredUserDTO.setInstituteName(object[7].toString());
            }
            if (object[8] != null) {
                registeredUserDTO.setAisheCode(object[8].toString());
            }
            if (object[9] != null) {
                registeredUserDTO.setUserStatus(Integer.valueOf(object[9].toString()));
            }
            if (object[10] != null) {
                registeredUserDTO.setUniversityName(object[10].toString());
            }


            if (object[10] == null) {
                String aisheCode = registeredUserDTO.getAisheCode();
                if (null == object[7]) {
                    if (null != aisheCode) {
                        String[] splitted = aisheCode.trim().split("\\s*-\\s*");
                        String instituteId = splitted[1];
                        String instituteType = splitted[0];
                        switch (instituteType.toUpperCase()) {
                            case "U": {
                                registeredUserDTO.setUniversityName(getNameByNative(NativeQuerySystem.IS_DCF_APPLICABLE_UNIVERSITY_NAME + instituteId + "') and id='" + instituteId + "'"));
                                break;
                            }
                            case "C": {
                                registeredUserDTO.setInstituteName(getNameByNative(NativeQuerySystem.IS_DCF_APPLICABLE_COLLEGE_NAME + instituteId + "') and id='" + instituteId + "'"));
                                break;
                            }
                            case "S": {
                                registeredUserDTO.setInstituteName(getNameByNative(NativeQuerySystem.IS_DCF_APPLICABLE_STANDALONE_NAME + instituteId + "') and id='" + instituteId + "'"));
                                break;
                            }
                        }
                    }
                }

            }
            if (formUploadStatus != null) {
                if (object[11] != null) {
                    registeredUserDTO.setFormUpload(object[11].toString() != null ? true : false);
                }
            }
            if (object[12] != null) {
                registeredUserDTO.setLevelName(object[12].toString());
            }
            if (object[13] != null) {
               // if (Integer.valueOf(object[9].toString()) == 2) {
                   // registeredUserDTO.setUserStatusName("Active");
               // } else {
                    registeredUserDTO.setUserStatusName(object[13].toString());
                }
            //}

            if (object[14] != null) {
                registeredUserDTO.setAddressLine1(object[14].toString());
            }
            if (object[15] != null) {
                registeredUserDTO.setAddressLine2(object[15].toString());
            }
            if (object[16] != null) {
                registeredUserDTO.setCity(object[16].toString());
            }
            if (object[17] != null) {
                registeredUserDTO.setPhone(object[17].toString());
            }
            if (object[18] != null) {
                registeredUserDTO.setMobile(object[18].toString());
            }
            if (object[19] != null) {
                registeredUserDTO.setEmailId(object[19].toString());
            }
            if (object[20] != null) {
                registeredUserDTO.setStateLevelBody(object[20].toString());
                if (object[10] == null) {
                    registeredUserDTO.setUniversityName(getNameByNative(NativeQuerySystem.IS_DCF_APPLICABLE_UNIVERSITY_NAME + object[20].toString() + "') and id='" + object[20].toString() + "'"));
                }
            }
            if (object[21] != null) {
                registeredUserDTO.setStateLevelBodyInstitute(object[21].toString());
            }
            if (object[22] != null) {
                registeredUserDTO.setBodyType(object[22].toString());
            }
            if (object[23] != null) {
                registeredUserDTO.setStdCode(object[23].toString());
            }
            if (object[24] != null) {
                registeredUserDTO.setAlternateEmailId(object[24].toString());
            }
            if (object[25] != null) {
                registeredUserDTO.setGender(object[25].toString());
            }
            if (object[26] != null) {
                registeredUserDTO.setRoleName(object[26].toString());
            }
            if (object[27] != null) {
                registeredUserDTO.setDistrictName(object[27].toString());
            }
            if (object[28] != null) {
                registeredUserDTO.setDistrictCode(object[28].toString());
            }
            if (object[29] != null) {
                registeredUserDTO.setDocument((byte[]) object[29]);
            }
            if (object[30] != null) {
                registeredUserDTO.setDocumentName(object[30]+"");
            }
            if (object[31] != null) {
                registeredUserDTO.setStateCode(object[31]+"");
            }
            userDTOS.add(registeredUserDTO);
        }
        return userDTOS;
    }

    @Override
    public BigInteger getRegisteredUserCont(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, String instituteType, String fromDate, String toDate, String searchText) {
        logger.info("RegisterationDaoImpl : getRegisteredUserCont method invoked :");
        Session session = sessionFactory.openSession();
        BigInteger result = null;
        StringBuilder queryBuilder = new StringBuilder();
        try {
            if (null != instituteType) {
                if (instituteType.equalsIgnoreCase("C")) {
                    if (formUploadStatus != null) {
                        if (formUploadStatus == true) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_COLLEGE_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_COLLEGE_WITHOUT_SURVEY);
                            }
                        } else {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_COUNT_COLLEGE);
                            }
                        }
                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.COUNT_COLLEGE_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.COUNT_COLLEGE_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("S")) {
                    if (formUploadStatus != null) {
                        if (formUploadStatus == true) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_STANDALONE_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_STANDALONE_WITHOUT_SURVEY);
                            }
                        } else {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_COUNT_STANDALONE);
                            }
                        }
                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.COUNT_STANDALONE_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.COUNT_STANDALONE_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("U")) {
                    if (formUploadStatus != null) {
                        if (formUploadStatus == true) {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_UNIVERSITY_WITH_SURVEY);
                            } else {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_COUNT_UNIVERSITY_WITHOUT_SURVEY);
                            }
                        } else {
                            if (surveyYear != null) {
                                queryBuilder.append(NativeQuerySystem.FORM_UPLOAD_UN_FILED_COUNT_UNIVERSITY);
                            }
                        }
                    } else {
                        if (surveyYear != null) {
                            queryBuilder.append(NativeQuerySystem.COUNT_UNIVERSITY_WITH_SURVEY);
                        } else {
                            queryBuilder.append(NativeQuerySystem.COUNT_UNIVERSITY_WITHOUT_SURVEY);
                        }
                    }
                }
                if (instituteType.equalsIgnoreCase("ALL")) {
                    if (null == formUploadStatus) {
                        queryBuilder.append(NativeQuerySystem.COUNT_OTHERS_USER);
                    }
                }

            } else {
                if (formUploadStatus == null)
                    queryBuilder.append(NativeQuerySystem.COUNT_OTHERS_USER);
            }
            if (formUploadStatus != null && formUploadStatus == false)
                queryBuilder = new StringBuilder(fillParameter(queryBuilder.toString(), surveyYear, formUploadStatus));
            String finalQuery = setParameterInQuery(queryBuilder.toString(), roleId, surveyYear, userStatus, deoRoleId, dcfStatus, formUploadStatus, stateCode, universityId, aisheCode, isApproved, instituteType, fromDate, toDate, searchText);

            Query query = session.createNativeQuery(finalQuery);
            query.setParameter("roleId", roleId);
            result = (BigInteger) query.getSingleResult();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;

    }

    private String fillParameter(String query, Integer surveyYear, Boolean formUplodStatus) {
        return query.replaceAll("=0", "=" + surveyYear);
    }

    private String setParameterInQuery(String query, Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, String instituteType, String fromDate, String toDate, String searchText) {
       /* if (null != roleId) {
            query = query + "where um.role_id=" + roleId;
        }*/
        if (null != searchText) {
            searchText = searchText.toLowerCase();
            if (null == instituteType || instituteType.equalsIgnoreCase("ALL")) {
                query = query + " and (lower(um.user_id) like '%" + searchText + "%'" +
                        " or lower(um.first_name) like '%" + searchText + "' " +
                        " or lower(um.middle_name) like '%" + searchText + "%' " +
                        " or lower(um.last_name) like '%" + searchText + "' " +
                        " or lower(um.email_id) like '%" + searchText + "%' " +
                        " or lower(um.phone_mobile) like '%" + searchText + "%' " +
                        " or lower(s.name) like '%" + searchText + "%' " +
                        " or lower(us.status) like '%" + searchText + "%' " +
                        " or lower(um.aishe_code) like '%" + searchText + "%'" +
                        " or lower(si.name) like '%" + searchText + "%'" +
                        " or lower(c.name) like '%" + searchText + "%'" +
                        " or lower(ru.name) like '%" + searchText + "%')";
            } else if (instituteType.equalsIgnoreCase("C")) {
                query = query + " and (lower(um.user_id) like '%" + searchText + "%'" +
                        " or lower(um.first_name) like '%" + searchText + "' " +
                        " or lower(um.middle_name) like '%" + searchText + "%' " +
                        " or lower(um.last_name) like '%" + searchText + "' " +
                        " or lower(um.email_id) like '%" + searchText + "%' " +
                        " or lower(um.phone_mobile) like '%" + searchText + "%' " +
                        " or lower(s.name) like '%" + searchText + "%' " +
                        " or lower(us.status) like '%" + searchText + "%' " +
                        " or lower(um.aishe_code) like '%" + searchText + "%'" +
                        " or lower(c.name) like '%" + searchText + "%'" +
                        " or lower(ru.name) like '%" + searchText + "%')";

            } else if (instituteType.equalsIgnoreCase("S") || instituteType.equalsIgnoreCase("U")) {
                query = query + " and (lower(um.user_id) like '%" + searchText + "%'" +
                        " or lower(um.first_name) like '%" + searchText + "' " +
                        " or lower(um.middle_name) like '%" + searchText + "%' " +
                        " or lower(um.last_name) like '%" + searchText + "' " +
                        " or lower(um.email_id) like '%" + searchText + "%' " +
                        " or lower(um.phone_mobile) like '%" + searchText + "%' " +
                        " or lower(s.name) like '%" + searchText + "%' " +
                        " or lower(us.status) like '%" + searchText + "%' " +
                        " or lower(um.aishe_code) like '%" + searchText + "%'" +
                        " or lower(c.name) like '%" + searchText + "%')";
            }
        }

        if (null != surveyYear && null != instituteType && instituteType.equalsIgnoreCase("C")) {
            query = query + " and c.survey_year=" + surveyYear + "and ru.survey_year=" + surveyYear;
        }

        if (null != surveyYear && null != instituteType && (!instituteType.equalsIgnoreCase("C") && !instituteType.equalsIgnoreCase("ALL"))) {
            query = query + " and c.survey_year=" + surveyYear;
        }
        if (null != userStatus) {
            query = query + " and um.status_id=" + userStatus;
        }
        if (null != deoRoleId) {
            query = query + " and um.deo_user_type=" + deoRoleId;
        }
        if (null != dcfStatus && null != instituteType && (!instituteType.equalsIgnoreCase("S"))) {
            query = query + " and c.is_dcf_applicable=" + dcfStatus;
        }
        if (null != formUploadStatus && null != surveyYear) {
            if (true == formUploadStatus) {
                query = query + " and fu.survey_year=" + surveyYear;
            } else {
                if (instituteType.equals("C")) {
                    query = query + " and c.survey_year=" + surveyYear + "and ru.survey_year=" + surveyYear;
                } else if (instituteType.equals("U") || instituteType.equals("S")) {
                    query = query + " and c.survey_year=" + surveyYear;
                }
            }

        }
        if (null != stateCode) {
            query = query + " and um.state_code='" + stateCode + "'";
        }
        if (null != universityId) {
            query = query + " and um.state_level_body='" + universityId + "'";
        }
        if (null != aisheCode) {
            query = query + " and um.aishe_code='" + aisheCode + "'";
        }
        if (null != isApproved) {
            int approve = isApproved == true ? 1 : 0;
            query = query + " and um.is_approved=" + approve;
        }
        if (null != toDate && null != fromDate) {
            LocalDate fromDateFrom = DateUtils.convertStringSlashDateToDBDate(fromDate);
            LocalDate fromDateTO = DateUtils.convertStringSlashDateToDBDate(toDate);
            query = query + " and  cast(um.registration_datetime as date) >='" + fromDateFrom + "' and cast(um.registration_datetime as date) <='" + fromDateTO + "'";
        }
        return query;
    }


    @Override
    public UserMasterDetailEO update(UserMasterDetailEO activeUser) {
        logger.info("RegisterationDaoImpl : saveUpdateRegistration method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.update(activeUser);
            tx.commit();
            return activeUser;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction " + trEx.getMessage());
                e.printStackTrace();
            }
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public UserRegistrationDetailEO saveUserRegistrationData(UserRegistrationDetailEO userMasterEO) {
        logger.info("RegisterationDaoImpl : saveUpdateRegistration method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            String newp = EncryptionDecryptionUtil.getDecryptedString(userMasterEO.getBcryptPassword());
            String oldp = EncryptionDecryptionUtil.getDecryptedString(userMasterEO.getConfirmBcryptPassword());
            boolean check = newp.equals(oldp);
            if (check) {
                userMasterEO.setBcryptPassword(bcrypt.encode(newp));
                userMasterEO.setUserPasswordInHash("999");
                userMasterEO.setStatusId(userMasterEO.getStatusId());
                userMasterEO.setRegistrationDatetime(DateUtils.obtainCurrentTimeStamp());
                session.save(userMasterEO);
                tx.commit();
            }
            return userMasterEO;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                e.printStackTrace();
            }
        } finally {
            session.close();
        }
        return null;
    }

	@Override
	public UserRegistrationUpdatedDetailEO updateUserRegistration(UserRegistrationUpdatedDetailEO userMasterEO) {
		 logger.info("RegisterationDaoImpl : saveUpdateRegistration method invoked :");
	        Session session = sessionFactory.openSession();
	        Transaction tx = null;
	        try {
	        	UserRegistrationUpdatedDetailEO checkForEmail = (UserRegistrationUpdatedDetailEO) session.get(UserRegistrationUpdatedDetailEO.class, userMasterEO.getUserId());
	            BeanUtils.copyProperties(userMasterEO, checkForEmail);
	        	tx = session.beginTransaction();
	            session.update(checkForEmail);
	            tx.commit();
	                return userMasterEO;
	        } catch (Exception e) {
	            try {
	                if (tx != null && tx.isActive()) {
	                    tx.rollback();
	                }
	            } catch (Exception trEx) {
	                e.printStackTrace();
	            }
	        } finally {
	            session.close();
	        }
	        return null;
	    }

	@Override
	public InstituteDetailEO getInstituteDetail(String aisheCode) {
		logger.info("InstitutionMasterDaoImpl getDetail method invoked");
		Session session = sessionFactory.openSession();
		
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<InstituteDetailEO> criteriaQuery = builder.createQuery(InstituteDetailEO.class);
			Root<InstituteDetailEO> root = criteriaQuery.from(InstituteDetailEO.class);
			List<Predicate> predicates = new ArrayList<Predicate>();
			if (aisheCode != null) {
				predicates.add(builder.equal(root.get("aisheCode"), aisheCode));
			}
			criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])))
					.orderBy(builder.desc(root.get("aisheCode")));
			Query<InstituteDetailEO> q = session.createQuery(criteriaQuery);
			List<InstituteDetailEO> list = q.getResultList();
			if(!list.isEmpty()) {
				return list.get(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}

	@Override
	public UserMasterDetailEO approveDisapprvoeUserApproval(ApproveDisapproveUserDTO approveUserDTO,
			HttpServletRequest request) {
		logger.info("approveDisapprvoeUserApproval method invoked");
		Session sessionGet = sessionFactory.openSession();
		Session sessionSave = sessionFactory.openSession();
		UserMasterDetailEO userMaster = new UserMasterDetailEO();
		UserMasterLogDetailEO userMasterLog = new UserMasterLogDetailEO();
		UserMasterRequestDetailEO userMasterRequest = new UserMasterRequestDetailEO();
		UserActionLog userActionLog = new UserActionLog();
		
		Transaction tx = null;
		try {
			switch (approveUserDTO.getStatus()) {
			case 2:
				userMasterRequest = (UserMasterRequestDetailEO)sessionGet.get(UserMasterRequestDetailEO.class,approveUserDTO.getUserId());
				if(userMasterRequest!=null) {
					BeanUtils.copyProperties(userMasterRequest, userMaster);
					tx=sessionSave.beginTransaction();
					userMaster.setApprovalMessage(approveUserDTO.getMessage());
					userMaster.setApprovedBy(approveUserDTO.getApprovedBy());
					userMaster.setApprovedDatetime(DateUtils.obtainCurrentTimeStamp());
					userMaster.setStatusId(2);
					sessionSave.saveOrUpdate(userMaster);
					sessionSave.delete(userMasterRequest);
					
					userActionLog.setUserId(approveUserDTO.getUserId());
					userActionLog.setInstitutionId(null);
					userActionLog.setInstitutionType(null);
					userActionLog.setActionId(8);
					userActionLog.setSurveyYear(0);
					userActionLog.setActionTime(DateUtils.obtainCurrentTimeStamp());
					userActionLog.setIpAddress(request.getRemoteAddr());
					userActionLog.setRemarks("UserId Approved and Delete from user request table.");
					userActionLog.setId(null);
					sessionSave.save(userActionLog);
					tx.commit();
					return userMaster;
				}
				
				break;
			case 3:
				userMaster = (UserMasterDetailEO)sessionGet.get(UserMasterDetailEO.class,approveUserDTO.getUserId());
				if(userMaster!=null) {
					BeanUtils.copyProperties(userMaster, userMasterLog);
					tx=sessionSave.beginTransaction();
					userMasterLog.setStatusId(3);
					sessionSave.saveOrUpdate(userMasterLog);
					sessionSave.delete(userMaster);
					
					userActionLog.setUserId(approveUserDTO.getUserId());
					userActionLog.setInstitutionId(null);
					userActionLog.setInstitutionType(null);
					userActionLog.setActionId(11);
					userActionLog.setSurveyYear(0);
					userActionLog.setActionTime(DateUtils.obtainCurrentTimeStamp());
					userActionLog.setIpAddress(request.getRemoteAddr());
					userActionLog.setRemarks("UserId Approved and Delete from user request table.");
					userActionLog.setId(null);
					sessionSave.save(userActionLog);
					tx.commit();
					return userMaster;
				}
				
				break;
			case 4:
				userMaster = (UserMasterDetailEO)sessionGet.get(UserMasterDetailEO.class,approveUserDTO.getUserId());
				if(userMaster!=null) {
					BeanUtils.copyProperties(userMaster, userMaster);
					tx=sessionSave.beginTransaction();
					userMaster.setApprovalMessage(approveUserDTO.getMessage());
					userMaster.setApprovedBy(approveUserDTO.getApprovedBy());
					userMaster.setApprovedDatetime(DateUtils.obtainCurrentTimeStamp());
					sessionSave.saveOrUpdate(userMaster);
					sessionSave.delete(userMasterRequest);
					
					userActionLog.setUserId(approveUserDTO.getUserId());
					userActionLog.setInstitutionId(null);
					userActionLog.setInstitutionType(null);
					userActionLog.setActionId(9);
					userActionLog.setSurveyYear(0);
					userActionLog.setActionTime(DateUtils.obtainCurrentTimeStamp());
					userActionLog.setIpAddress(request.getRemoteAddr());
					userActionLog.setRemarks("UserId Approved and Delete from user request table.");
					userActionLog.setId(null);
					sessionSave.save(userActionLog);
					tx.commit();
					return userMaster;
				}
				
				break;
			}
		} catch (Exception e) {
			  try {
	                if (tx != null && tx.isActive()) {
	                    tx.rollback();
	                }
	            } catch (Exception trEx) {
	                e.printStackTrace();
	            }
			e.printStackTrace();
		}finally {
			sessionGet.close();
			sessionSave.close();
		}
		return null;
	}

}