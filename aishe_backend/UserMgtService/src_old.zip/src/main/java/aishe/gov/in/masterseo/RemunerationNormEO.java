package aishe.gov.in.masterseo;

import aishe.gov.in.utility.RemunerationKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.Valid;

@Setter
@Getter
@Builder
@ToString
@AllArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "public.remuneration_norm")
public class RemunerationNormEO {
    @EmbeddedId
    @Valid
    private RemunerationKey remunerationKey;
    @Column(name = "type_id")
    private Integer typeId;
    @Column(name = "is_frezeed")
    private Boolean isFrezeed;
    /* @Column(name = "aishe_code")
    private String aisheCode;
    @Column(name = "institute_type")
    private String instituteType;*/
}
