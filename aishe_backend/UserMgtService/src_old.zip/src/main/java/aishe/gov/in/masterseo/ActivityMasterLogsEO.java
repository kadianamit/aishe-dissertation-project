package aishe.gov.in.masterseo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "public.activity_master_log")
public class ActivityMasterLogsEO {

	@Id
	@Column(name = "id")
	private Integer id;
	@Column(name = "activity_master_id")
	private Integer activityMasterId;
	@Column(name = "user_id")
	private String userId;
	@Column(name = "action_id")
	private Integer actionId;
	@Column(name = "survey_year")
	private Integer surveyYear;
	@Column(name = "start_date")
	private LocalDate startDate;
	@Column(name = "end_date")
	private LocalDate endDate;	
	@Column(name = "prev_start_date")
	private LocalDate prevStartDate;
	@Column(name = "prev_end_date")
	private LocalDate prevEndDate;
	@Column(name = "action_date")
	private LocalDate actionDate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getActionId() {
		return actionId;
	}
	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}
	public Integer getSurveyYear() {
		return surveyYear;
	}
	public void setSurveyYear(Integer surveyYear) {
		this.surveyYear = surveyYear;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public LocalDate getPrevStartDate() {
		return prevStartDate;
	}
	public void setPrevStartDate(LocalDate prevStartDate) {
		this.prevStartDate = prevStartDate;
	}
	public LocalDate getPrevEndDate() {
		return prevEndDate;
	}
	public void setPrevEndDate(LocalDate prevEndDate) {
		this.prevEndDate = prevEndDate;
	}
	public LocalDate getActionDate() {
		return actionDate;
	}
	public void setActionDate(LocalDate actionDate) {
		this.actionDate = actionDate;
	}
	public Integer getActivityMasterId() {
		return activityMasterId;
	}
	public void setActivityMasterId(Integer activityMasterId) {
		this.activityMasterId = activityMasterId;
	}		
}