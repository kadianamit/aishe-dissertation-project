package aishe.gov.in.mastersvo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;

@Setter
@Getter
public class AfiiliatedWithUniversityCount {
    private BigInteger totalAffiliatedCollege;
    private BigInteger totalFormUploadedAffiliatedCollege;
}
