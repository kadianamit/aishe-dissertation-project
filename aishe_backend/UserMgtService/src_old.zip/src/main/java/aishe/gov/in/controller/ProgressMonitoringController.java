package aishe.gov.in.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import aishe.gov.in.mastersvo.FinalProgressMonitoringDayWiseDTO;
import aishe.gov.in.mastersvo.FormUploadDateWiseDTO;
import aishe.gov.in.mastersvo.ProgressMonitoringBasicDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import aishe.gov.in.enums.FormType;
import aishe.gov.in.enums.InstitutionType;
import aishe.gov.in.mastersvo.InstituteDetailDTO;
import aishe.gov.in.mastersvo.ProgressMoniteringDTO;
import aishe.gov.in.mastersvo.ProgressMonitoringDTO;
import aishe.gov.in.service.ProgressMonitoringService;
import aishe.gov.in.utility.ReturnResponse;

@RestController
@RequestMapping("/api")
public class ProgressMonitoringController {

    @Autowired
    private ProgressMonitoringService monitoringService;

    @GetMapping(value = "/progressMonitoring")
    public ResponseEntity<ReturnResponse> getProgressMonitoring(@RequestParam Integer surveyYear,
                                                                @RequestParam(required = false) String stateCode,
                                                                @RequestParam(required = false) String universityId,
                                                                @RequestParam(required = false) String fromDate,
                                                                @RequestParam(required = false) String toDate, @RequestParam InstitutionType institutionType, @RequestParam(required = false) Integer roleId) {
        List<ProgressMoniteringDTO> registeredUserDTO = monitoringService.getProgressMonitoring(surveyYear, stateCode, universityId, fromDate, toDate, institutionType, roleId);

        ReturnResponse returnResponse = new ReturnResponse(HttpStatus.OK.value(), "success ", registeredUserDTO != null ? registeredUserDTO : Collections.EMPTY_LIST);
        return new ResponseEntity<>(returnResponse, HttpStatus.valueOf(returnResponse.getStatus()));
    }

    @GetMapping(value = "/progressMonitoringByType")
    public ResponseEntity<ReturnResponse> getInstituteDetailOfProgressMonitoring(@RequestParam Integer surveyYear,
                                                                                 @RequestParam(required = false) String stateCode,
                                                                                 @RequestParam(required = false) String universityId,
                                                                                 @RequestParam(required = false) String fromDate,
                                                                                 @RequestParam(required = false) String toDate,
                                                                                 @RequestParam InstitutionType institutionType,
                                                                                 @RequestParam String type, @RequestParam FormType formType/*,
                                                                                 @RequestParam(required = false) String searchText,*/
                                                               /* @RequestParam int page, @RequestParam int pageSize*/) {
        /*if (pageSize <= 0 || page <= 0) {
            ReturnResponse returnResponse = new ReturnResponse(HttpStatus.BAD_REQUEST.value(), "invalid page or page size ");
            return new ResponseEntity<>(returnResponse, HttpStatus.valueOf(returnResponse.getStatus()));
        }*/
        List<InstituteDetailDTO> registeredUserDTO = monitoringService.getInstituteDetailOfProgressMonitoring(surveyYear, stateCode, universityId, fromDate, toDate, institutionType, type, formType/*, page, pageSize, searchText*/);
        ReturnResponse returnResponse = new ReturnResponse(HttpStatus.OK.value(), "success ", registeredUserDTO != null ? registeredUserDTO : Collections.EMPTY_LIST);
        return new ResponseEntity<>(returnResponse, HttpStatus.valueOf(returnResponse.getStatus()));
    }

    @GetMapping(value = "/progressMonitoringByBasicCount")
    public ResponseEntity<ReturnResponse> getProgressMonitoringByBasicCount(@RequestParam Integer surveyYear,
                                                                            @RequestParam(required = false) String fromDate,
                                                                            @RequestParam(required = false) String toDate, @RequestParam InstitutionType institutionType) {
        ProgressMonitoringDTO registeredUserDTO = monitoringService.getProgressMonitoringByBasicCount(surveyYear, fromDate, toDate, institutionType);

        registeredUserDTO.setDayWise(setProgressMonitoringDayWise(registeredUserDTO));

        ReturnResponse returnResponse = new ReturnResponse(HttpStatus.OK.value(), "success ", registeredUserDTO != null ? registeredUserDTO : Collections.EMPTY_LIST);
        return new ResponseEntity<>(returnResponse, HttpStatus.valueOf(returnResponse.getStatus()));
    }


    List<FinalProgressMonitoringDayWiseDTO> setProgressMonitoringDayWise(ProgressMonitoringDTO registeredUserDTO) {
        List<FinalProgressMonitoringDayWiseDTO> list = new ArrayList<>();
        CopyOnWriteArrayList<String> list1 = new CopyOnWriteArrayList<>();
        if (null != registeredUserDTO) {

            ProgressMonitoringBasicDTO college = registeredUserDTO.getCollege();
            ProgressMonitoringBasicDTO standalone = registeredUserDTO.getStandalone();
            ProgressMonitoringBasicDTO university = registeredUserDTO.getUniversity();
            if (null != college) {
                List<FormUploadDateWiseDTO> dayWise = college.getDayWise();
                if (!dayWise.isEmpty()) {
                    for (FormUploadDateWiseDTO dto : dayWise) {
                        FinalProgressMonitoringDayWiseDTO wiseDTO = new FinalProgressMonitoringDayWiseDTO();
                        if (!list1.contains(dto.getDate())) {
                            wiseDTO.setDate(dto.getDate());
                            list1.addIfAbsent(dto.getDate());
                            wiseDTO.setCollege(dto.getTotalCount());
                            if (null != standalone) {
                                List<FormUploadDateWiseDTO> sdayWise = standalone.getDayWise();
                                if (!sdayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : sdayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setStandalone(s.getTotalCount());
                                        }

                                    }
                            }
                            if (null != university) {
                                List<FormUploadDateWiseDTO> udayWise = university.getDayWise();
                                if (!udayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : udayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setUniversity(s.getTotalCount());
                                        }

                                    }
                            }
                            list.add(wiseDTO);
                        }

                    }
                }
            }
            if (null != standalone) {
                List<FormUploadDateWiseDTO> standaloneDayWise = standalone.getDayWise();
                if (!standaloneDayWise.isEmpty()) {
                    for (FormUploadDateWiseDTO dto : standaloneDayWise) {
                        FinalProgressMonitoringDayWiseDTO wiseDTO = new FinalProgressMonitoringDayWiseDTO();
                        if (!list1.contains(dto.getDate())) {
                            wiseDTO.setDate(dto.getDate());
                            list1.addIfAbsent(dto.getDate());
                            wiseDTO.setStandalone(dto.getTotalCount());

                            if (null != college) {
                                List<FormUploadDateWiseDTO> sdayWise = college.getDayWise();
                                if (!sdayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : sdayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setCollege(s.getTotalCount());
                                        }

                                    }
                            }

                            if (null != university) {
                                List<FormUploadDateWiseDTO> udayWise = university.getDayWise();
                                if (!udayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : udayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setUniversity(s.getTotalCount());
                                        }

                                    }
                            }
                            list.add(wiseDTO);
                        }

                    }
                }

            }
            if (null != university) {
                List<FormUploadDateWiseDTO> universityDayWise = university.getDayWise();
                if (!universityDayWise.isEmpty()) {
                    for (FormUploadDateWiseDTO dto : universityDayWise) {
                        FinalProgressMonitoringDayWiseDTO wiseDTO = new FinalProgressMonitoringDayWiseDTO();
                        if (!list1.contains(dto.getDate())) {
                            wiseDTO.setDate(dto.getDate());
                            list1.addIfAbsent(dto.getDate());
                            wiseDTO.setUniversity(dto.getTotalCount());

                            if (null != college) {
                                List<FormUploadDateWiseDTO> sdayWise = college.getDayWise();
                                if (!sdayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : sdayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setCollege(s.getTotalCount());
                                        }

                                    }
                            }

                            if (null != standalone) {
                                List<FormUploadDateWiseDTO> udayWise = standalone.getDayWise();
                                if (!udayWise.isEmpty())
                                    for (FormUploadDateWiseDTO s : udayWise) {
                                        if (s.getDate().equals(wiseDTO.getDate())) {
                                            wiseDTO.setStandalone(s.getTotalCount());
                                        }

                                    }
                            }
                            list.add(wiseDTO);
                        }

                    }
                }
            }

        }
        return list;
    }

}
