package aishe.gov.in.enums;

public interface Constant {
    String COLLEGE = "/college/";
    String COLLEGE_LANDSCAPE = "/collegelandscape/";
    String STANDALONE = "/standalone/";
    String UNIVERSITY = "/university/";
    String COLLEGE_TEACHER = "/collegeteacher/";
    String STANDALONE_TEACHER = "/standaloneteacher/";
    String UNIVERSITY_TEACHER = "/universityteacher/";
    String APPLICATION_X_DOWNLOAD = "application/x-download";
    String EXCEL_XLSX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    String EXCEL_XLS_CONTENT_TYPE = "application/vnd.ms-excel";

    String CSV_CONTENT_TYPE = "text/csv";
    String CSV_EXTENSION = ".csv";
    String CONTENT_DISPOSITION = "Content-Disposition";
    String GOV_AISHE_IN = "gov.aishe.in";
    String TEACHING_STAFF = "-TeachingStaff";
    String REGIONAL_CENTER = "/regionalCenter/";
    String WEBDCF_UNLOCK = "/WebdcfUnlock/";
    int firstRow = 1;
    int firstCol = 17;
    int lastCol = 112;
    int ZERO = 0;
    int ONE = 1;
    String COLLEGEOLD = "/college1/";
    String UNIVERSITYSUBMIT = "/UniversitySubmit/";
    String COLLEGESUBMIT = "/CollegeSubmit/";
    String STANDALONESUBMIT = "/StandaloneSubmit/";
    String COLLEGE_LANDSCAPE_OLD = "/collegelandscape1/";
    String STANDALONEOLD = "/standalone1/";
    String UNIVERSITYOLD = "/university1/";
    String COLLEGE_TEACHER_OLD = "/collegeteacher1/";
    String STANDALONE_TEACHER_OLD = "/standaloneteacher1/";
    String UNIVERSITY_TEACHER_OLD = "/universityteacher1/";
    String CERTIFICATE = "/certificate/";
    String CERTIFICATEOLD = "/certificateold/";
    String REGIONAL_CENTER_ONE = "/regionalCenter1/";
    String SEPCIAL_PERMISSION = "/SpecialPermission/";
    int BYTE_SIZE = 1024;
    int FOLDER_SIZE = 25;
    String REQUEST_CANNOT_BE_PROCESSED = "Request Cannot Be Processed. Please Try Again.";
    String SUCCESS = "success";
    String UNAUTHORIZED_USER = "Unauthorised User(Token Expired)";
    String ANTOHER_CONSULTANT = "This Record is Assigned to Other Consultant";
    Integer UNAUTHORIZED_USER_VALUE = 402;
    String ACTIVITY_DETAIL_ASSOCIATE = " Items Of Activity Detail are associate With ";
    String FINANCIAL_ESTIMATE_ASSOCIATE = " Items Of Proposal Financial Estimate are associate With ";
    String PROPOSAL_TIMELINE_ASSOCIATE = " Items Of Proposal Timeline Estimate are associate With ";

    String ACTIVITY_BASE_PATH = "/reports/Activity/";
    String COLLEGE_BASE_PATH = "/reports/College/";
    String EQUITY_BASE_PATH = "/reports/Equity/";
    String MERU_BASE_PATH = "/reports/Meru/";
    String NMDC_BASE_PATH = "/reports/NMDC/";
    String UNIVERSITY_BASE_PATH = "/reports/University/";

    String PROPOSAL_BASE_PATH = "/reports/Proposal/";
    String CREATED_BY = "created_by";
    String RELATIVE_PATH = "real_path";
    String component_id = "componentId";
    String aishe_code = "aishe_code";
    String district_code = "district_code";

    String state_code = "state_code";

}
