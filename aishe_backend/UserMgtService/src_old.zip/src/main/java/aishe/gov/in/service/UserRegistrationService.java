package aishe.gov.in.service;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import aishe.gov.in.enums.SortBy;
import aishe.gov.in.masterseo.ApproveDisapproveUserDTO;
import aishe.gov.in.masterseo.ApproveUserDTO;
import aishe.gov.in.masterseo.InstituteDetailEO;
import aishe.gov.in.masterseo.UserMasterDetailEO;
import aishe.gov.in.masterseo.UserMasterEO;
import aishe.gov.in.masterseo.UserMasterNewEO;
import aishe.gov.in.masterseo.UserRegistrationDetailEO;
import aishe.gov.in.masterseo.UserRegistrationUpdatedDetailEO;
import aishe.gov.in.mastersvo.RegisteredUserDTO;
import aishe.gov.in.mastersvo.UserApprovalDTO;

public interface UserRegistrationService {
    public UserMasterNewEO saveUpdateRegistration(UserMasterNewEO userMasterEO, HttpServletRequest request);

    public UserMasterEO getUserRegistration(String userId, Integer currentSurveyYear);

    public UserMasterDetailEO saveAndUpdateUserApproval(UserApprovalDTO approvalDTO, HttpServletRequest request);

    public Boolean deleteUser(String userId, HttpServletRequest request);

    public List<RegisteredUserDTO> getRegisteredUser(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, SortBy sortBy, String instituteType,/* int page, int pageSize,*/ String fromDate,String toDate,String searchText);

    public BigInteger getRegisteredUserCont(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, String instituteType, String fromDate,String toDate,String searchText);

    public UserMasterDetailEO saveUserApproval(ApproveUserDTO approveUserDTO,HttpServletRequest request);

	public UserRegistrationDetailEO saveUserRegistrationData(UserRegistrationDetailEO userMasterEO);

	public UserRegistrationUpdatedDetailEO updateUserRegistration(UserRegistrationUpdatedDetailEO userMasterEO);

	public InstituteDetailEO getInstituteDetail(String aisheCode);

	public void updateInfoInstituteDetail(InstituteDetailEO instituteDetail);

	public UserMasterDetailEO approveDisapprvoeUserApproval(ApproveDisapproveUserDTO approveUserDTO,
			HttpServletRequest request);

}
