package aishe.gov.in.dao;

import aishe.gov.in.enums.FormType;
import aishe.gov.in.enums.InstitutionType;
import aishe.gov.in.masterseo.RefStateBody;
import aishe.gov.in.masterseo.RefUniversityCollegeType;
import aishe.gov.in.masterseo.RefUniversityType;
import aishe.gov.in.mastersvo.FormUploadDateWiseDTO;
import aishe.gov.in.mastersvo.InstituteDetailDTO;
import aishe.gov.in.mastersvo.ProgressMoniteringDTO;
import aishe.gov.in.mastersvo.ProgressMonitoringBasicDTO;
import aishe.gov.in.mastersvo.ProgressMonitoringDTO;
import aishe.gov.in.utility.DateUtils;
import aishe.gov.in.utility.QueryParameterResolver;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class ProgressMonitoringDaoImpl implements ProgressMonitoringDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private RefMasterDao refMasterDao;

    @Autowired
    private QueryParameterResolver parameterResolver;

    @Override
    public List<ProgressMoniteringDTO> getProgressMonitoring(Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, InstitutionType institutionType, Integer roleId) {
        Session session = sessionFactory.openSession();
        List<RefUniversityType> universityTypes = null;
        List<RefUniversityCollegeType> collegeTypes = null;
        List<RefStateBody> stateBodies = null;
        List<ProgressMoniteringDTO> dtoList = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(18);
        list.add(22);
        list.add(8);
        list.add(9);
        list.add(10);
        list.add(11);
        if (!list.contains(roleId)) {
            collegeTypes = refMasterDao.getRefUniversityCollegeType();
            if (null == universityId || universityId.equalsIgnoreCase("null")) {
                universityTypes = refMasterDao.getRefUniversityType();
                stateBodies = refMasterDao.getRefStateBody();
            }
        } else {
            switch (roleId) {
                case 3:
                case 8: {
                    stateBodies = refMasterDao.getRefStateBody(2, 7);
                    break;
                }
                case 4:
                case 9: {
                    stateBodies = refMasterDao.getRefStateBody(3, null);
                    break;
                }
                case 5:
                case 10: {
                    stateBodies = refMasterDao.getRefStateBody(4, null);
                    break;
                }
                case 11:
                case 18: {
                    stateBodies = refMasterDao.getRefStateBody(1, null);
                    break;
                }
                case 22: {
                    stateBodies = refMasterDao.getRefStateBody(6, 0);
                    break;
                }
            }
        }
        try {
            switch (institutionType.getType()) {
                case "C": {
                    if (null != collegeTypes)
                        for (RefUniversityCollegeType universityType : collegeTypes) {
                            dtoList.add(collegeObjectBind(session, universityType, surveyYear, stateCode, universityId, fromDate, toDate, null));
                        }
                    break;
                }
                case "U": {
                    if (null != universityTypes)
                        for (RefUniversityType universityType : universityTypes) {
                            dtoList.add(universityObjectBind(session, universityType, surveyYear, stateCode, fromDate, toDate));
                        }
                    break;

                }
                case "S": {
                    if (null != stateBodies)
                        for (RefStateBody universityType : stateBodies) {
                            dtoList.add(standaloneObjectBind(session, universityType, surveyYear, stateCode, fromDate, toDate));
                        }
                    break;
                }
                default: {
                    if (null != universityTypes)
                        for (RefUniversityType universityType : universityTypes) {
                            dtoList.add(universityObjectBind(session, universityType, surveyYear, stateCode, fromDate, toDate));
                        }
                    if (null != collegeTypes)
                        for (RefUniversityCollegeType universityType : collegeTypes) {
                            dtoList.add(collegeObjectBind(session, universityType, surveyYear, stateCode, universityId, fromDate, toDate, null));
                        }
                    if (null != stateBodies)
                        for (RefStateBody universityType : stateBodies) {
                            dtoList.add(standaloneObjectBind(session, universityType, surveyYear, stateCode, fromDate, toDate));
                        }
                    break;
                }
            }

            return dtoList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public List<InstituteDetailDTO> getInstituteDetailOfProgressMonitoring(Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, InstitutionType institutionType, String type, FormType formType/*, int page, int pageSize, String searchText*/) {

        Session session = sessionFactory.openSession();
        try {
            switch (institutionType.getType()) {
                case "C": {
                    if (null != type)
                        return collegeExpectedSubmittedBind(session, type, surveyYear, stateCode, universityId, fromDate, toDate, formType, institutionType/*, page, pageSize*/);
                }
                case "S": {
                    if (null != type)
                        return standaloneExpectedSubmittedBind(session, type, surveyYear, stateCode, null, fromDate, toDate, formType, institutionType/*, page, pageSize*/);
                }
                case "U": {
                    if (null != type)
                        return universityExpectedSubmittedBind(session, type, surveyYear, stateCode, null, fromDate, toDate, formType, institutionType/*, page, pageSize*/);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public ProgressMonitoringDTO getProgressMonitoringByBasicCount(Integer surveyYear, String fromDate, String toDate, InstitutionType institutionType) {
        Session session = sessionFactory.openSession();
        ProgressMonitoringDTO dto = new ProgressMonitoringDTO();
        try {
            switch (institutionType.getType()) {
                case "C": {
                    dto.setCollege(collegeObjectBind(session, surveyYear, fromDate, toDate));
                    break;
                }
                case "S": {
                    dto.setStandalone(standaloneObjectBind(session, surveyYear, fromDate, toDate));
                    break;
                }
                case "U": {
                    dto.setUniversity(universityObjectBind(session, surveyYear, fromDate, toDate));
                    break;
                }
                case "ALL": {
                    dto.setUniversity(universityObjectBind(session, surveyYear, fromDate, toDate));
                    dto.setCollege(collegeObjectBind(session, surveyYear, fromDate, toDate));
                    dto.setStandalone(standaloneObjectBind(session, surveyYear, fromDate, toDate));
                    return dto;
                }
            }
            return dto;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    private ProgressMoniteringDTO standaloneObjectBind(Session session, RefStateBody universityType, Integer surveyYear, String stateCode, String fromDate, String toDate) {
        ProgressMoniteringDTO dto = new ProgressMoniteringDTO();
        dto.setFormType("Standalone");
        dto.setTypeId(universityType.getId().toString());
        dto.setTypeName(universityType.getType());
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.standaloneParameterBinder(NativeQuerySystem.IS_DCF_APPLICABLE_STANDALONE, surveyYear, stateCode, Integer.valueOf(universityType.getId())/**/));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalFormExpected(result);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.standaloneParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_STANDALONE, surveyYear, stateCode, Integer.valueOf(universityType.getId())/**/), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
        BigInteger totalResult = (BigInteger) totalQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        return dto;
    }

    private List<FormUploadDateWiseDTO> bindObjectInTODto(List<Object[]> userListData, String fromDate, String toDate) {
        List<FormUploadDateWiseDTO> list = new ArrayList<>();
        for (Object[] object : userListData) {
            FormUploadDateWiseDTO registeredUserDTO = new FormUploadDateWiseDTO();
            if (object[0] != null) {
                registeredUserDTO.setTotalCount((BigInteger) object[0]);
            }
            if (object[1] != null) {
                registeredUserDTO.setDate(DateUtils.convertDBSlashDateToString(LocalDate.parse(object[1].toString())));
            }
            list.add(registeredUserDTO);
        }
        return list;
    }

    private String dayWise(String query, String fromDate, String toDate) {
        StringBuilder builder = new StringBuilder();
        builder.append(query);
        if (null != fromDate && null != toDate) {
            if ((fromDate != "null" && toDate != "null")) {
                if (!fromDate.equals(toDate)) {
                    LocalDate fromDateFrom = DateUtils.convertStringSlashDateToDBDate(fromDate);
                    LocalDate fromDateTO = DateUtils.convertStringSlashDateToDBDate(toDate);

                    builder.append(" and cast(fu.upload_date as date) >='" + fromDateFrom + "' and cast(fu.upload_date as date) <='" + fromDateTO + "'");
                    // builder.append(" and  fu.upload_date BETWEEN  '" + fromDateFrom + "' and '" + fromDateTO + "'");
                } else {
                    LocalDate fromDateTO = DateUtils.convertStringSlashDateToDBDate(toDate);
                    builder.append(" and  cast(fu.upload_date as text) like '" + fromDateTO + "%'");
                }
            }
        }

        builder = builder.append(" group by DATE(fu.upload_date)  order by upload_date asc ");
        return builder.toString();
    }

    private ProgressMonitoringBasicDTO collegeObjectBind(Session session, Integer surveyYear, String fromDate, String toDate) {
        ProgressMonitoringBasicDTO dto = new ProgressMonitoringBasicDTO();
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        StringBuilder totalBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.collegeParameterBinder(NativeQuerySystem.BASIC_FILLED_COLLEGE, surveyYear, null, null, null));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalBasicFilled(result);

        totalBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.collegeParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_COLLEGE, surveyYear, null, null, null), fromDate, toDate, surveyYear));
        Query totalFormQuery = session.createNativeQuery(totalBuilder.toString());
        BigInteger totalResult = (BigInteger) totalFormQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.collegeParameterBinder(NativeQuerySystem.FORM_UPLOAD_COLLEGE, surveyYear, null, null, null), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(dayWise(totalQueryBuilder.toString(), fromDate, toDate));
        List<Object[]> userListData = totalQuery.getResultList();
        dto.setDayWise(bindObjectInTODto(userListData, toDate, toDate));
        return dto;
    }

    private ProgressMonitoringBasicDTO universityObjectBind(Session session, Integer surveyYear, String fromDate, String toDate) {
        ProgressMonitoringBasicDTO dto = new ProgressMonitoringBasicDTO();
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        StringBuilder totalBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.universityParameterBinder(NativeQuerySystem.BASIC_FILLED_UNIVERSITY, surveyYear, null, null));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalBasicFilled(result);
        totalBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.universityParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_UNIVERSITY, surveyYear, null, null), fromDate, toDate, surveyYear));
        Query totalFormQuery = session.createNativeQuery(totalBuilder.toString());
        BigInteger totalResult = (BigInteger) totalFormQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.universityParameterBinder(NativeQuerySystem.FORM_UPLOAD_UNIVERSITY, surveyYear, null, null), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(dayWise(totalQueryBuilder.toString(), fromDate, toDate));
        List<Object[]> userListData = totalQuery.getResultList();
        dto.setDayWise(bindObjectInTODto(userListData, fromDate, toDate));
        return dto;
    }

    private ProgressMonitoringBasicDTO standaloneObjectBind(Session session, Integer surveyYear, String fromDate, String toDate) {
        ProgressMonitoringBasicDTO dto = new ProgressMonitoringBasicDTO();
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        StringBuilder totalBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.standaloneParameterBinder(NativeQuerySystem.BASIC_FILLED_STANDALONE, surveyYear, null, null));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalBasicFilled(result);
        totalBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.standaloneParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_STANDALONE, surveyYear, null, null), fromDate, toDate, surveyYear));
        Query totalFormQuery = session.createNativeQuery(totalBuilder.toString());
        BigInteger totalResult = (BigInteger) totalFormQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.standaloneParameterBinder(NativeQuerySystem.FORM_UPLOAD_STANDALONE, surveyYear, null, null), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(dayWise(totalQueryBuilder.toString(), fromDate, toDate));
        List<Object[]> userListData = totalQuery.getResultList();
        dto.setDayWise(bindObjectInTODto(userListData, fromDate, toDate));
        return dto;
    }

    private ProgressMoniteringDTO collegeObjectBind(Session session, RefUniversityCollegeType universityType, Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, String searchText) {
        ProgressMoniteringDTO dto = new ProgressMoniteringDTO();
        dto.setFormType("College");
        dto.setTypeId(universityType.getId());
        dto.setTypeName(universityType.getType());
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.collegeParameterBinder(NativeQuerySystem.IS_DCF_APPLICABLE_COLLEGE, surveyYear, stateCode, universityType.getId(), universityId));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalFormExpected(result);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.collegeParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_COLLEGE, surveyYear, stateCode, universityType.getId(), universityId), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
        BigInteger totalResult = (BigInteger) totalQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        return dto;
    }


    private List<InstituteDetailDTO> collegeExpectedSubmittedBind(Session session, String universityType, Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, FormType formType, InstitutionType institutionType/*, int page, int pageSize, String searchText*/) {
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        List<Object[]> userListData = null;
        if (formType.getType() == 1) {
            expectedQueryBuilder.append(parameterResolver.collegeParameterBinder(NativeQuerySystem.EXPECTED_AISHE_CODE_AND_NAME_OF_COLLEGE, surveyYear, stateCode, universityType, universityId));
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
            /*expectedQuery.setFirstResult((page - 1) * pageSize);
            expectedQuery.setMaxResults(pageSize);*/
            userListData = (List<Object[]>) expectedQuery.getResultList();
        } else if (formType.getType() == 3) {
            expectedQueryBuilder.append(parameterResolver.collegeParameterBinder("select 'C-'||c.id as aishe_code,c.name from college c where 1=1 ", surveyYear, stateCode, universityType, universityId));
            expectedQueryBuilder.append(" and c.id not in (select college_institution_id from form_upload as fu where form_id='form2' and survey_year='" + surveyYear + "')");
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
            userListData = (List<Object[]>) expectedQuery.getResultList();

        } else {
            totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.collegeParameterBinder(NativeQuerySystem.SUBMITTED_AISHE_CODE_AND_NAME_OF_COLLEGE, surveyYear, stateCode, universityType, universityId), fromDate, toDate, surveyYear));
            Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
           /* totalQuery.setFirstResult((page - 1) * pageSize);
            totalQuery.setMaxResults(pageSize);*/
            userListData = (List<Object[]>) totalQuery.getResultList();
        }
        if (null != userListData) {
            return setObject(userListData, institutionType.getType());
        }
        return null;
    }

    private List<InstituteDetailDTO> universityExpectedSubmittedBind(Session session, String universityType, Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, FormType formType, InstitutionType institutionType) {
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        List<Object[]> userListData = null;
        if (formType.getType() == 1) {
            expectedQueryBuilder.append(parameterResolver.universityParameterBinder(NativeQuerySystem.EXPECTED_AISHE_CODE_AND_NAME_OF_UNIVERSITY, surveyYear, stateCode, universityType));
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
            userListData = (List<Object[]>) expectedQuery.getResultList();
        } else if (formType.getType() == 3) {
            expectedQueryBuilder.append(parameterResolver.universityParameterBinder("select 'U-'||ru.id as aishe_code,ru.name from ref_university ru where 1=1 ", surveyYear, stateCode, universityType));
            expectedQueryBuilder.append(" and ru.id not in (select university_id from form_upload as fu where form_id='form1' and survey_year='" + surveyYear + "')");
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
            userListData = (List<Object[]>) expectedQuery.getResultList();
        } else {
            totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.universityParameterBinder(NativeQuerySystem.SUBMITTED_AISHE_CODE_AND_NAME_OF_UNIVERSITY, surveyYear, stateCode, universityType), fromDate, toDate, surveyYear));
            Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
            /*totalQuery.setFirstResult((page - 1) * pageSize);
            totalQuery.setMaxResults(pageSize);*/
            userListData = (List<Object[]>) totalQuery.getResultList();
        }
        if (null != userListData) {
            return setObject(userListData, institutionType.getType());
        }
        return null;
    }

    private List<InstituteDetailDTO> standaloneExpectedSubmittedBind(Session session, String universityType, Integer surveyYear, String stateCode, String universityId, String fromDate, String toDate, FormType formType, InstitutionType institutionType/*, int page, int pageSize, String searchText*/) {
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        List<Object[]> userListData = null;
        if (formType.getType() == 1) {
            expectedQueryBuilder.append(parameterResolver.standaloneParameterBinder(NativeQuerySystem.EXPECTED_AISHE_CODE_AND_NAME_OF_STANDALONE, surveyYear, stateCode, Integer.valueOf(universityType)/**/));
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
           /* expectedQuery.setFirstResult((page - 1) * pageSize);
            expectedQuery.setMaxResults(pageSize);*/
            userListData = (List<Object[]>) expectedQuery.getResultList();
        } else if (formType.getType() == 3) {
            expectedQueryBuilder.append(parameterResolver.standaloneParameterBinder("select 'S-'||si.id as aishe_code,si.name from ref_standalone_institution si ", surveyYear, stateCode, Integer.valueOf(universityType)/**/));
            expectedQueryBuilder.append(" and si.id not in (select standalone_institution_id from form_upload as fu where form_id='form3' and survey_year='" + surveyYear + "')");
            Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
            userListData = (List<Object[]>) expectedQuery.getResultList();
        } else {
            totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.standaloneParameterBinder(NativeQuerySystem.SUBMITTED_AISHE_CODE_AND_NAME_OF_STANDALONE, surveyYear, stateCode, Integer.valueOf(universityType)/**/), fromDate, toDate, surveyYear));
            Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
            /*totalQuery.setFirstResult((page - 1) * pageSize);
            totalQuery.setMaxResults(pageSize);*/
            userListData = (List<Object[]>) totalQuery.getResultList();
        }
        if (null != userListData) {
            return setObject(userListData, institutionType.getType());
        }
        return null;
    }

    private List<InstituteDetailDTO> setObject(List<Object[]> userListData, String institutionType) {
        List<InstituteDetailDTO> dtoList = new ArrayList<>();
        for (Object[] object : userListData) {

            InstituteDetailDTO registeredUserDTO = new InstituteDetailDTO();
            registeredUserDTO.setFormType(institutionType);
            if (object[0] != null) {
                registeredUserDTO.setAisheCode(object[0].toString());

            }
            if (object[1] != null) {
                registeredUserDTO.setInstituteName(object[1].toString());
            }
            dtoList.add(registeredUserDTO);
        }
        return dtoList;
    }

    private ProgressMoniteringDTO universityObjectBind(Session session, RefUniversityType universityType, Integer surveyYear, String stateCode, String fromDate, String toDate) {
        ProgressMoniteringDTO dto = new ProgressMoniteringDTO();
        dto.setFormType("University");
        dto.setTypeId(universityType.getId());
        dto.setTypeName(universityType.getType());
        StringBuilder expectedQueryBuilder = new StringBuilder();
        StringBuilder totalQueryBuilder = new StringBuilder();
        expectedQueryBuilder.append(parameterResolver.universityParameterBinder(NativeQuerySystem.IS_DCF_APPLICABLE_UNIVERSITY, surveyYear, stateCode, universityType.getId()));
        Query expectedQuery = session.createNativeQuery(expectedQueryBuilder.toString());
        BigInteger result = (BigInteger) expectedQuery.getSingleResult();
        dto.setTotalFormExpected(result);
        totalQueryBuilder.append(parameterResolver.fromUploadParameterBinder(parameterResolver.universityParameterBinder(NativeQuerySystem.TOTAL_FORM_UPLOAD_UNIVERSITY, surveyYear, stateCode, universityType.getId()), fromDate, toDate, surveyYear));
        Query totalQuery = session.createNativeQuery(totalQueryBuilder.toString());
        BigInteger totalResult = (BigInteger) totalQuery.getSingleResult();
        dto.setTotalFormUploaded(totalResult);
        return dto;
    }

}
