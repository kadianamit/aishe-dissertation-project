package aishe.gov.in.dao;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import aishe.gov.in.enums.SortBy;
import aishe.gov.in.masterseo.ApproveDisapproveUserDTO;
import aishe.gov.in.masterseo.ApproveUserDTO;
import aishe.gov.in.masterseo.InstituteDetailEO;
import aishe.gov.in.masterseo.UserMasterDetailEO;
import aishe.gov.in.masterseo.UserMasterDetailStateEO;
import aishe.gov.in.masterseo.UserMasterEO;
import aishe.gov.in.masterseo.UserMasterNewEO;
import aishe.gov.in.masterseo.UserRegistrationDetailEO;
import aishe.gov.in.masterseo.UserRegistrationUpdatedDetailEO;
import aishe.gov.in.mastersvo.RegisteredUserDTO;

public interface RegisterationDao {
    UserMasterNewEO saveUpdateRegistration(UserMasterNewEO userMasterEO);

    UserMasterEO getUserRegistration(String userId);

    UserMasterDetailEO getUserByUserId(String userId);

    UserMasterDetailEO save(UserMasterDetailEO UserMasterDetailEO);

    Boolean deleteUser(UserMasterDetailEO masterEO);

    List<UserMasterDetailStateEO> getUserByCondition(Integer roleId, String aisheCode, Integer userStatus, String stateCode, String UniversityId, Integer deoRoleId, Boolean isApproved);

    List<RegisteredUserDTO> getRegisteredUser(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved, SortBy sortBy, String instituteType, /*int page, int pageSize,*/String fromDate,String toDate,String searchText);

    BigInteger getRegisteredUserCont(Integer roleId, Integer surveyYear, Integer userStatus, Integer deoRoleId, Boolean dcfStatus, Boolean formUploadStatus, String stateCode, String universityId, String aisheCode, Boolean isApproved,  String instituteType,String fromDate,String toDate,String searchText);

    UserMasterDetailEO getUser(ApproveUserDTO approveUserDTO);

    UserMasterDetailEO update(UserMasterDetailEO activeUser);

	UserRegistrationDetailEO saveUserRegistrationData(UserRegistrationDetailEO userMasterEO);

	UserMasterEO getUserRegistration1(String userId);

	UserRegistrationUpdatedDetailEO updateUserRegistration(UserRegistrationUpdatedDetailEO userMasterEO);

	InstituteDetailEO getInstituteDetail(String aisheCode);

	UserMasterDetailEO approveDisapprvoeUserApproval(ApproveDisapproveUserDTO approveUserDTO,
			HttpServletRequest request);

}
