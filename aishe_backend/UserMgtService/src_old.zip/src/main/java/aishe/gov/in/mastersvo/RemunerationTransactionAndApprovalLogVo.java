package aishe.gov.in.mastersvo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class RemunerationTransactionAndApprovalLogVo {
    private String stateName;
    private String institutionType;
    private String formId;
    private String institutionId;
    private String institutionName;
    private String uploadDate;
    private String surveyYear;
    private String formUploadId;
    private String status;
    private String timestamp;
    private String userId;
    private String ipAddress;
}
