package aishe.gov.in.dao;

import java.util.List;

import aishe.gov.in.masterseo.CollegeAffiliationLogEO;
import aishe.gov.in.masterseo.CollegeEO;
import aishe.gov.in.masterseo.UniversityRef;
import aishe.gov.in.mastersvo.CollegeDeaffiliationAffiliationVO;

public interface CollegeAffiliationDeaffliationDao {

    CollegeEO getCollegeMaster(String collegeId, Integer surveyYear);

    List<CollegeEO> getCollegeMasterList(String collegeId, Integer surveyYear);

    UniversityRef getUniversityMaster(String universityId, Integer surveyYear);

    Boolean saveCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef oldUniversityRef, UniversityRef newUnversityRef);

    Boolean saveUpdateCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef newUnversityRef);

    CollegeAffiliationLogEO getCollegeAffiliationLogBySurveyYear(String universityId, Integer surveyYear);
}
