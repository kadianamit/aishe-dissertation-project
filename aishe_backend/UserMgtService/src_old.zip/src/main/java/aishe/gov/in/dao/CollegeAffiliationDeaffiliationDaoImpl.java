package aishe.gov.in.dao;

import aishe.gov.in.masterseo.CollegeAffiliationLogEO;
import aishe.gov.in.masterseo.CollegeEO;
import aishe.gov.in.masterseo.CollegeInstitutionEO;
import aishe.gov.in.masterseo.UniversityRef;
import aishe.gov.in.mastersvo.CollegeDeaffiliationAffiliationVO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class CollegeAffiliationDeaffiliationDaoImpl implements CollegeAffiliationDeaffliationDao {

    @Autowired
    private SessionFactory sessionFactory;

    private static final Logger logger = LoggerFactory.getLogger(CollegeAffiliationDeaffiliationDaoImpl.class);

    @Override
    public CollegeEO getCollegeMaster(String collegeId, Integer surveyYear) {
        logger.info("AffiliationDeaffiliationDaoImpl : getCollegeMaster method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<CollegeEO> criteriaQuery = builder.createQuery(CollegeEO.class);
            Root<CollegeEO> root = criteriaQuery.from(CollegeEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();

            if (collegeId != null) {
                predicates.add(builder.equal(root.get("universityPk").get("id"), collegeId));
            }
            if (surveyYear != null) {
                predicates.add(builder.equal(root.get("universityPk").get("surveyYear"), surveyYear));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<CollegeEO> q = session.createQuery(criteriaQuery);

            return q.uniqueResult();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }
    @Override
    public List<CollegeEO> getCollegeMasterList(String collegeId, Integer surveyYear) {
        logger.info("AffiliationDeaffiliationDaoImpl : getCollegeMasterList method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<CollegeEO> criteriaQuery = builder.createQuery(CollegeEO.class);
            Root<CollegeEO> root = criteriaQuery.from(CollegeEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();

            if (collegeId != null) {
                predicates.add(builder.equal(root.get("universityPk").get("id"), collegeId));
            }
            if (surveyYear != null) {
                predicates.add(builder.greaterThan(root.get("universityPk").get("surveyYear"), surveyYear));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<CollegeEO> q = session.createQuery(criteriaQuery);
            return q.getResultList();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public UniversityRef getUniversityMaster(String universityId, Integer surveyYear) {
        logger.info("AffiliationDeaffiliationDaoImpl : getUniversityMaster method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<UniversityRef> criteriaQuery = builder.createQuery(UniversityRef.class);
            Root<UniversityRef> root = criteriaQuery.from(UniversityRef.class);
            List<Predicate> predicates = new ArrayList<Predicate>();
            if (universityId != null) {
                predicates.add(builder.equal(root.get("id"), universityId));
            }
            if (surveyYear != null) {
                predicates.add(builder.equal(root.get("surveyYear"), surveyYear));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<UniversityRef> q = session.createQuery(criteriaQuery);
            return q.uniqueResult();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public CollegeAffiliationLogEO getCollegeAffiliationLogBySurveyYear(String collegId, Integer surveyYear) {
        logger.info("AffiliationDeaffiliationDaoImpl : getCollegeAffiliationLogBySurveyYear method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<CollegeAffiliationLogEO> criteriaQuery = builder.createQuery(CollegeAffiliationLogEO.class);
            Root<CollegeAffiliationLogEO> root = criteriaQuery.from(CollegeAffiliationLogEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();
            if (collegId != null) {
                predicates.add(builder.equal(root.get("id"), collegId));
            }
            if (surveyYear != null) {
                predicates.add(builder.equal(root.get("surveyYear"), surveyYear));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<CollegeAffiliationLogEO> q = session.createQuery(criteriaQuery);
            return q.uniqueResult();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }


    public CollegeInstitutionEO getCollegeTansaction(String collegeId, Integer surveyYear) {
        logger.info("AffiliationDeaffiliationDaoImpl : getCollegeTansaction method invoked :");
        Session session = sessionFactory.openSession();
        try {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<CollegeInstitutionEO> criteriaQuery = builder.createQuery(CollegeInstitutionEO.class);
            Root<CollegeInstitutionEO> root = criteriaQuery.from(CollegeInstitutionEO.class);
            List<Predicate> predicates = new ArrayList<Predicate>();
            if (collegeId != null) {
                predicates.add(builder.equal(root.get("collegePk").get("id"), Integer.parseInt(collegeId)));
            }
            if (surveyYear != null) {
                predicates.add(builder.equal(root.get("collegePk").get("surveyYear"), surveyYear));
            }
            criteriaQuery.select(root).where(builder.and(predicates.toArray(new Predicate[predicates.size()])));
            Query<CollegeInstitutionEO> q = session.createQuery(criteriaQuery);
            return q.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return null;
    }

    @Override
    public Boolean saveCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef oldUniversityRef, UniversityRef newUnversityRef) {
        logger.info("AffiliationDeaffiliationDaoImpl : saveCollegeAffiliationDeaffiliation method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        Integer id = null;
        try {

            tx = session.beginTransaction();
            CollegeAffiliationLogEO logEO = getCollegeAffiliationLogBySurveyYear(deaffiliationAffiliationVO.getCollegeAisheCode(), null);
            Timestamp currrentTime = new Timestamp(new Date().getTime());
            if (null == logEO) {
                CollegeAffiliationLogEO affiliationLog = new CollegeAffiliationLogEO();
                affiliationLog.setId(Integer.parseInt(deaffiliationAffiliationVO.getCollegeAisheCode()));
                affiliationLog.setAffiliatedBy(deaffiliationAffiliationVO.getUsername());
                affiliationLog.setName(collegeEO.getName());
                affiliationLog.setAffiliatingUniversityId(newUnversityRef.getId());
                affiliationLog.setAffiliationDatetime(currrentTime);
                if (!(oldUniversityRef.getId().equals(newUnversityRef.getId()))) {
                    affiliationLog.setDeaffiliatedBy(deaffiliationAffiliationVO.getUsername());
                    affiliationLog.setDeaffiliationDatetime(currrentTime);
                    affiliationLog.setDeaffiliatingUniversityId(oldUniversityRef.getId());
                }
                affiliationLog.setSurveyYear(deaffiliationAffiliationVO.getSurveyYear());
                session.saveOrUpdate(affiliationLog);
            } else {
                logEO.setAffiliatedBy(deaffiliationAffiliationVO.getUsername());
                logEO.setAffiliatingUniversityId(newUnversityRef.getId());
                logEO.setAffiliationDatetime(currrentTime);
                if (!(oldUniversityRef.getId().equals(newUnversityRef.getId())) && null != oldUniversityRef.getId()) {
                    logEO.setDeaffiliatedBy(deaffiliationAffiliationVO.getUsername());
                    logEO.setDeaffiliationDatetime(currrentTime);
                    logEO.setDeaffiliatingUniversityId(oldUniversityRef.getId());
                }
                logEO.setSurveyYear(deaffiliationAffiliationVO.getSurveyYear());
                session.update(logEO);
            }
            tx.commit();
            session.close();
            return true;

        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction" + trEx.getMessage());
            }
            logger.info("getCollegeMaster Error" + e.getMessage());
        } finally {
            session.close();
        }
        return false;
    }

    @Override
    public Boolean saveUpdateCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef newUnversityRef) {
        logger.info("AffiliationDeaffiliationDaoImpl : saveUpdateCollegeAffiliationDeaffiliation method invoked :");
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        try {

            tx = session.beginTransaction();
            collegeEO.setUniversityId(newUnversityRef.getId());
            session.update(collegeEO);
            //Search college according to survey year
            CollegeInstitutionEO collegeInstitutionEO = getCollegeTansaction(deaffiliationAffiliationVO.getCollegeAisheCode(), deaffiliationAffiliationVO.getSurveyYear());
            if (null != collegeInstitutionEO) {
                //tx2 = session3.beginTransaction();
                collegeInstitutionEO.setUniversityId(newUnversityRef.getId());
                session.update(collegeInstitutionEO);
            }
            tx.commit();
            session.close();
            return true;
        } catch (Exception e) {
            try {
                if (tx != null && tx.isActive()) {
                    tx.rollback();
                }
            } catch (Exception trEx) {
                logger.error("Couldn’t roll back transaction" + trEx.getMessage());
            }
            logger.info("saveUpdateCollegeAffiliationDeaffiliation Error" + e.getMessage());
        } finally {
            session.close();
        }
        return false;
    }
}


