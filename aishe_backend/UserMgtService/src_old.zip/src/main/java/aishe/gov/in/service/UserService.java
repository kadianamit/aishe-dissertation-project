package aishe.gov.in.service;

import aishe.gov.in.masterseo.OtpDetailsMouEO;
import aishe.gov.in.mastersvo.ChangePasswordDTO;
import aishe.gov.in.mastersvo.ForgotPasswordDto;
import aishe.gov.in.mastersvo.ResetPasswordDTO;

public interface UserService {

    String findByEmailIdIgnoreCase(String email);

    boolean saveForgotPassword(OtpDetailsMouEO forgot);

    String verifyOtpForogtPassword(ForgotPasswordDto forgotPassword);

	String findByAisheCodeIgnoreCase(String aisheCode);

	boolean updateUserPassword(String userId, String oldPassword, String confirmPassword, String newPassword);
    boolean resetPassword(ResetPasswordDTO resetPassword);

    boolean changePassword(ChangePasswordDTO changePassword);
}