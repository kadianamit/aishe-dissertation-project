package aishe.gov.in.utility;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.Objects;
@AllArgsConstructor
@RequiredArgsConstructor
@Setter
@Getter
@Builder
@Embeddable
public class CisoEmadedPK implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -2748123577249192483L;
	@Column(name = "agency_code")
    private String agencyCode;
    private String post;
   // @Column(name = "agency_name")
   // private String agencyName;


    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof CisoEmadedPK))
            return false;
        CisoEmadedPK that = (CisoEmadedPK) o;
        return Objects.equals(getAgencyCode(), that.getAgencyCode()) && Objects.equals(getPost(), that.getPost());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAgencyCode(), getPost());
    }

}
