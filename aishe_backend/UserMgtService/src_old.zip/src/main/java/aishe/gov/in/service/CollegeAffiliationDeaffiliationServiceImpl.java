package aishe.gov.in.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import aishe.gov.in.dao.CollegeAffiliationDeaffliationDao;
import aishe.gov.in.dao.UserActionLogDao;
import aishe.gov.in.masterseo.CollegeEO;
import aishe.gov.in.masterseo.UniversityRef;
import aishe.gov.in.masterseo.UserActionLogEONew;
import aishe.gov.in.mastersvo.CollegeDeaffiliationAffiliationVO;

@Service
public class CollegeAffiliationDeaffiliationServiceImpl implements CollegeAffiliationDeaffiliationService {
    @Autowired
    private CollegeAffiliationDeaffliationDao affiliationDeaffliationDao;
    @Autowired
    private UserActionLogDao userActionLogDao;

    @Override
    public CollegeEO getCollegeMaster(String collegeId, Integer surveyYear) {
        return affiliationDeaffliationDao.getCollegeMaster(collegeId, surveyYear);
    }

    @Override
    public UniversityRef getUniversityMaster(String universityId, Integer surveyYear) {
        return affiliationDeaffliationDao.getUniversityMaster(universityId, surveyYear);
    }

    @Override
    public Boolean saveUpdateCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef oldUniversityRef, UniversityRef newUnversityRef) {
        Integer surveyyear=deaffiliationAffiliationVO.getSurveyYear();
        affiliationDeaffliationDao.saveCollegeAffiliationDeaffiliation(deaffiliationAffiliationVO, collegeEO, oldUniversityRef, newUnversityRef);
       // Integer userLogMaxId = userActionLogDao.getMaxId();
        UserActionLogEONew userActionLog = new UserActionLogEONew( deaffiliationAffiliationVO.getUsername(), deaffiliationAffiliationVO.getCollegeAisheCode(), "C", 21, surveyyear, new Timestamp(new Date().getTime()), deaffiliationAffiliationVO.getIpAddress(), "college de-affiliated");
        userActionLogDao.saveUserActionLog(userActionLog);
        affiliationDeaffliationDao.saveUpdateCollegeAffiliationDeaffiliation(deaffiliationAffiliationVO, collegeEO, newUnversityRef);
        List<CollegeEO> eoList = affiliationDeaffliationDao.getCollegeMasterList(deaffiliationAffiliationVO.getCollegeAisheCode(), deaffiliationAffiliationVO.getSurveyYear());
        if (eoList.size() > 0) {
            eoList.parallelStream().forEach(college -> {
                affiliationDeaffliationDao.saveUpdateCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO.bindSurveyYear(deaffiliationAffiliationVO, college.getUniversityPk().getSurveyYear()), college, newUnversityRef);
            });
        }
        UserActionLogEONew userActionLog2 = new UserActionLogEONew( deaffiliationAffiliationVO.getUsername(), deaffiliationAffiliationVO.getCollegeAisheCode(), "C", 22, surveyyear, new Timestamp(new Date().getTime()), deaffiliationAffiliationVO.getIpAddress(), "college affiliated");
        userActionLogDao.saveUserActionLog(userActionLog2);
        return true;
    }
}
