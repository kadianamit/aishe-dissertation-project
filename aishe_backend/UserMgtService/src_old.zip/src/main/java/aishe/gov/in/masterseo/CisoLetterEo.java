package aishe.gov.in.masterseo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@ToString
@AllArgsConstructor
@RequiredArgsConstructor
@Setter
@Getter
@Entity
@Builder
@Table(name = "ciso.ciso_letter")
public class CisoLetterEo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NotNull
    @NotBlank
    @Column(name = "agency_code")
    private String agencyCode;
    @NotNull
    @NotBlank
    private String post;
    @Column(name = "letter_title")
    private String letterTittle;
    @Column(name = "letter")
    private byte[] letter;
    @Column(name = "remarks")
    private String remarks;
    @JsonIgnore
    @Column(name = "issue_date")
    private LocalDate issueDate;
    @Transient
    private String issuedDated;
}
