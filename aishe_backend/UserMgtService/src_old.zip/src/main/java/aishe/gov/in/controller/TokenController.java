package aishe.gov.in.controller;

import java.text.ParseException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import aishe.gov.in.mastersvo.AisheCodeDetailsVo;
import aishe.gov.in.mastersvo.CollegeCountUniversityWise;
import aishe.gov.in.mastersvo.CreatedInstituteDetailsVo;
import aishe.gov.in.mastersvo.ResponseVO;
import aishe.gov.in.mastersvo.TokenInfo;
import aishe.gov.in.mastersvo.UserDetailsVo;
import aishe.gov.in.security.UserInfo;
import aishe.gov.in.security.WithUser;
import aishe.gov.in.service.UserTokenService;
import aishe.gov.in.utility.ReturnResponse;

@RestController
public class TokenController {
    private static final Logger logger = LoggerFactory.getLogger(TokenController.class);
    @Autowired
    private UserTokenService universityService;
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping(value = "/refreshToken")
    public ResponseVO refreshToken(@RequestParam String userId, @RequestParam String token, @WithUser UserInfo userInfo) throws ParseException {
        logger.info("university controller : refreshToken method invoked : {}");
        ResponseVO responseVO = universityService.refreshToken(userId, token);
        return responseVO;
    }

    @GetMapping(value = "/logoutwebdcf")
    public ResponseEntity<ReturnResponse> logoutWebDcf(@RequestParam String userId, @WithUser UserInfo userInfo) throws ParseException {
        logger.info("university controller : refreshToken method invoked : {}");
        Boolean responseVO = universityService.logOutWebDcf(userId);
        if (responseVO) {
            return new ResponseEntity<>(new ReturnResponse(HttpStatus.OK.value(), "You Are Successfully Logout From Webdcf!!"), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(new ReturnResponse(HttpStatus.BAD_REQUEST.value(), "Request Cannot Be Processed. Please Try Again."), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/userdetails")
    public List<UserDetailsVo> userDetailsAisheByUserId(@RequestParam String userId, @WithUser UserInfo userInfo) throws ParseException {
        logger.info("university controller : userDetails method invoked : {}");
        List<UserDetailsVo> responseVO = universityService.userDetails(userId);
        return responseVO;
    }

    @GetMapping(value = "/userdetailsasaishecode")
    public List<UserDetailsVo> userDetailsOnBasisAisheCode(@RequestParam String aisheCode) throws ParseException {
        logger.info("university controller : userDetails method invoked : {}");
        List<UserDetailsVo> responseVO = universityService.userDetailsaISHEcODE(aisheCode);
        return responseVO;
    }
    
    @GetMapping(value = "/userdetailsasaishecodeall")
    public List<UserDetailsVo> userDetailsOnBasisAisheCodeAll(@RequestParam String aisheCode) throws ParseException {
        logger.info("university controller : userDetails method invoked : {}");
        List<UserDetailsVo> responseVO = universityService.userDetailsOnBasisAisheCodeAll(aisheCode);
        return responseVO;
    }

    @GetMapping(value = "/userdetailsmou")
    public List<UserDetailsVo> userDetails(@RequestParam String userId) throws ParseException {
        logger.info("university controller : userDetails method invoked : {}");
        List<UserDetailsVo> responseVO = universityService.userDetails(userId);
        return responseVO;
    }

    @GetMapping(value = "/bharatapitoken")
    public TokenInfo getAccessToken(@WithUser UserInfo userInfo) {
        HttpHeaders header = new HttpHeaders();
        String loginurl = "https://egw.bharatapi.gov.in/token";
        //String clientcode = "TbWZLCHDZOxAkK167iaf4VguKE0a"; ashish
        //String clientSecret = "oriufgQvzpdVHsIZ6VXbx3eaM_0a";
        String clientcode = "nAsSI6Kd7IMs6m0h533HdOL1F30a";
        String clientSecret = "X1IsFRyW6q5eQZvlQWE4ivhzW3ga";
        header.setAccessControlAllowOrigin("*");
        // header.add("Accept","application/x-www-form-urlencoded");
        // header.add("Content-Type","application/x-www-form-urlencoded");
        // header.add("grant_type","password_credentials");//if password_credentials
        header.add("grant_type", "client_credentials");
        header.add("client_id", clientcode);
        header.add("client_secret", clientSecret);
        String encodedCredentials = clientcode + clientSecret;
        String encodedString = Base64.getEncoder().encodeToString(encodedCredentials.getBytes());
        header.add("Authorization", "Bearer " + encodedString);
        ResponseEntity<TokenInfo> tokenoauth = restTemplate.postForEntity(loginurl, header, TokenInfo.class);
        TokenInfo tokens = tokenoauth.getBody();
        return tokens;
    }
    
    @GetMapping(value = "/aishecodedetailscsy")
    public Map<String,AisheCodeDetailsVo> userDetailsByAisheCodeOnCurrentSurveyYear(@RequestParam String aisheCode,@RequestParam Integer currentSurveyYear) {
        String[] splitted = aisheCode.trim().split("\\s*-\\s*");
        String instituteId = splitted[1];
        String instituteType = splitted[0];
        AisheCodeDetailsVo responseVO = universityService.userDetailsByAisheCodeOnCurrentSurveyYear(instituteType,instituteId,currentSurveyYear);
        Map<String,AisheCodeDetailsVo> details = new HashMap<String,AisheCodeDetailsVo>();
        details.put("Institute Details For CSY",responseVO);
        return details;
    }
    
    @GetMapping(value = "/collegecountuniversitywise")
    public List<CollegeCountUniversityWise> universityWiseCollege(@RequestParam Integer surveyYear){
        List<CollegeCountUniversityWise> responseVO = universityService.universityWiseCollege(surveyYear);
        return responseVO;
    }
    
    @GetMapping(value = "/createdinstitutedetailsaishecode")
    public List<CreatedInstituteDetailsVo> createdInstituteDetailsOnBasisAisheCode(@RequestParam String aisheCode) throws ParseException {
    	String[] splitted = aisheCode.trim().split("\\s*-\\s*");
        String instituteId = splitted[1];
        String instituteType = splitted[0];
        logger.info("university controller : createdInstituteDetailsOnBasisAisheCode method invoked : {}");
        List<CreatedInstituteDetailsVo> responseVO = universityService.createdInstituteDetailsOnBasisAisheCode(instituteType,instituteId);
        return responseVO;
    }
}
