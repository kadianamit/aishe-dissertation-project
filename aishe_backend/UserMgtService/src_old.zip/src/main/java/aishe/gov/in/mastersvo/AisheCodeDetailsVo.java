package aishe.gov.in.mastersvo;

public class AisheCodeDetailsVo {
	private Integer lsy;
	
	private String elligible;
	
	private Boolean specialPermission=false;

	public Integer getLsy() {
		return lsy;
	}

	public void setLsy(Integer lsy) {
		this.lsy = lsy;
	}

	public String getElligible() {
		return elligible;
	}

	public void setElligible(String elligible) {
		this.elligible = elligible;
	}

	public Boolean getSpecialPermission() {
		return specialPermission;
	}

	public void setSpecialPermission(Boolean specialPermission) {
		this.specialPermission = specialPermission;
	}
}