package aishe.gov.in.mastersvo;

public class CollegeCountUniversityWise {
	private Long collegeCount;
	private String universityId;
	private String universityName;
	private Integer surveyYear;
	private String stateName;
	public Long getCollegeCount() {
		return collegeCount;
	}
	public void setCollegeCount(Long collegeCount) {
		this.collegeCount = collegeCount;
	}
	public String getUniversityId() {
		return universityId;
	}
	public void setUniversityId(String universityId) {
		this.universityId = universityId;
	}
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public Integer getSurveyYear() {
		return surveyYear;
	}
	public void setSurveyYear(Integer surveyYear) {
		this.surveyYear = surveyYear;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
}
