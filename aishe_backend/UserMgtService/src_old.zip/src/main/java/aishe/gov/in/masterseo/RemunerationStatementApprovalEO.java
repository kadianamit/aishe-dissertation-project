package aishe.gov.in.masterseo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import java.io.Serializable;
import java.sql.Timestamp;

@AllArgsConstructor
@RequiredArgsConstructor
@Setter
@Getter

@Builder
@Entity
@Table(name = "remuneration_statement_approval")
public class RemunerationStatementApprovalEO implements Serializable {

    private static final long serialVersionUID = 67321414153041797L;
    @Id
    @Embedded
    @Valid
    private RemunerationStatementApprovalKey approvalKey;
    @JsonIgnore
    @Column(name = "ip_address")
    private String ipAddress;
    @Column(name = "approver_id")
    private String approverUserId;
    @Column(name = "status_id")
    private Integer statusId;
    @Column(name = "remarks")
    private String remarks;
    @JsonIgnore
    @Column(name = "timestamp")
    private Timestamp timestamp;
}
