package aishe.gov.in.service;

import aishe.gov.in.masterseo.CollegeEO;
import aishe.gov.in.masterseo.UniversityRef;
import aishe.gov.in.mastersvo.CollegeDeaffiliationAffiliationVO;

public interface CollegeAffiliationDeaffiliationService {

    CollegeEO getCollegeMaster(String collegeId, Integer surveyYear);

    UniversityRef getUniversityMaster(String universityId, Integer surveyYear);

    Boolean saveUpdateCollegeAffiliationDeaffiliation(CollegeDeaffiliationAffiliationVO deaffiliationAffiliationVO, CollegeEO collegeEO, UniversityRef oldUniversityRef, UniversityRef newUnversityRef);
}
